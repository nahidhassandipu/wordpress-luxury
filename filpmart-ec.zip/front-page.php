<?php get_header();?>

<?php 
    
    /*

    Template Name: Home

    */

 ?>



    <!--  HEADER : END  -->
    <div class="body-content outer-top-xs" id="top-banner-and-menu">
      <div class="container">
        <div class="row">
          <!-- SIDEBAR  -->	
          
		  
		  <?php get_template_part('left-sideber');?>
		  
          <!-- SIDEBAR : END  -->
          <!-- CONTENT -->
          <div class="col-xs-12 col-sm-12 col-md-9 homebanner-holder">
            <!-- SECTION – HERO -->
            <div id="hero">
              <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
                <div class="item" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/sliders/01.jpg);">
                  <div class="container-fluid">
                    <div class="caption bg-color vertical-center text-left">
                      <div class="slider-header fadeInDown-1">Top Brands</div>
                      <div class="big-text fadeInDown-1">
                        New Collections
                      </div>
                      <div class="excerpt fadeInDown-2 hidden-xs">
                        <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span>
                      </div>
                      <div class="button-holder fadeInDown-3">
                        <a href="index6c11.html?page=single-product" class="btn-lg btn btn-uppercase btn-primary shop-now-button">Shop Now</a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/sliders/02.jpg);">
                  <div class="container-fluid">
                    <div class="caption bg-color vertical-center text-left">
                      <div class="slider-header fadeInDown-1">Spring 2016</div>
                      <div class="big-text fadeInDown-1">
                        Women <span class="highlight">Fashion</span>
                      </div>
                      <div class="excerpt fadeInDown-2 hidden-xs">
                        <span>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit</span>
                      </div>
                      <div class="button-holder fadeInDown-3">
                        <a href="index6c11.html?page=single-product" class="btn-lg btn btn-uppercase btn-primary shop-now-button">Shop Now</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- INFO BOXES  -->
            <div class="info-boxes wow fadeInUp">
              <div class="info-boxes-inner">
                <div class="row">
                  <div class="col-md-6 col-sm-4 col-lg-4">
                    <div class="info-box">
                      <div class="row">
                        <div class="col-xs-12">
                          <h4 class="info-box-heading green">money back</h4>
                        </div>
                      </div>
                      <h6 class="text">30 Days Money Back Guarantee</h6>
                    </div>
                  </div>
                  <div class="hidden-md col-sm-4 col-lg-4">
                    <div class="info-box">
                      <div class="row">
                        <div class="col-xs-12">
                          <h4 class="info-box-heading green">free shipping</h4>
                        </div>
                      </div>
                      <h6 class="text">Shipping on orders over $99</h6>
                    </div>
                  </div>
                  <div class="col-md-6 col-sm-4 col-lg-4">
                    <div class="info-box">
                      <div class="row">
                        <div class="col-xs-12">
                          <h4 class="info-box-heading green">Special Sale</h4>
                        </div>
                      </div>
                      <h6 class="text">Extra $5 off on all items </h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--  SCROLL TABS  -->
            <div id="product-tabs-slider" class="scroll-tabs outer-top-vs wow fadeInUp">
              <div class="more-info-tab clearfix ">
                <h3 class="new-product-title pull-left">New Products</h3>
                <ul class="nav nav-tabs nav-tab-line pull-right" id="new-products-1">    
                  <li class="active"><a data-transition-type="backSlide" href="#all" data-toggle="tab">All</a></li>
                  <li><a data-transition-type="backSlide" href="#smartphone" data-toggle="tab">Clothing</a></li>
                  <li><a data-transition-type="backSlide" href="#laptop" data-toggle="tab">Electronics</a></li>
                  <li><a data-transition-type="backSlide" href="#apple" data-toggle="tab">Shoes</a></li>
                </ul>
                <!-- /.nav-tabs -->
              </div>
              <div class="tab-content outer-top-xs">
                <div class="tab-pane in active" id="all">
                  <div class="product-slider">
                    <div class="owl-carousel home-owl-carousel custom-carousel owl-theme" data-item="4">
                    <?php
                    global $product;
                    $accessories = array( 
                      'post_type' => 'product', 
                      'posts_per_page' => 12, 
                      'product_cat' => get_the_terms( get_the_ID(), 'product_cat' ), 
                      'orderby' => 'ASC' 
                    );
                    $loop_accessories = new WP_Query( $accessories );
                    while ( $loop_accessories->have_posts() ): $loop_accessories->the_post();  ?>
                      <div class="item item-carousel">
                        <div class="products">
                          <div class="product">

                            <a href="<?php echo get_permalink( $loop_accessories->post->ID ) ?>" title="<?php echo esc_attr($loop_accessories->post->post_title ? $loop_accessories->post->post_title : $loop_accessories->post->ID); ?>"> 
                            
                              <div class="product-image">
                                <div class="image">
                                  <?php if (has_post_thumbnail( $loop_accessories->post->ID )) echo get_the_post_thumbnail($loop_accessories->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" />'; ?>
                                </div>

                                <?php 
                                $sale_price = $product->get_sale_price();
                                if (!empty($sale_price)): ?>
                                <div class="tag hot">
                                  <span>
                                    <?php woocommerce_show_product_sale_flash( $post, $product ); ?>
                                    </span>
                                </div>
                              <?php endif; ?>
                              </div>

                              <div class="product-info text-left">
                                <h3 class="name"><?php the_title(); ?></h3>
                                <div class="rating rateit-small"></div>
                                <div class="description"></div>
                                <div class="product-price"> 
                                  <span class="price">
                                    <?php echo get_woocommerce_currency_symbol(); ?>
                                    <?php echo $product->get_regular_price(); ?>
                                  </span>
                                  <span class="price-before-discount">
                                    <?php 
                                      if( $product->is_on_sale() ) {
                                        echo get_woocommerce_currency_symbol();
                                        echo $product->get_sale_price();
                                      } ?>
                                  </span>
                                </div>
                              </div>
                            </a>
                              <?php woocommerce_template_loop_add_to_cart( $loop_accessories->post, $product ); ?> 
                          </div>
                        </div>
                      </div>
                    <?php endwhile; ?>
                  <?php wp_reset_query(); ?>
                    </div>
                  </div>
                </div>

                <div class="tab-pane" id="smartphone">
                  <div class="product-slider">
                    <div class="owl-carousel home-owl-carousel custom-carousel owl-theme">

                    <?php $music = array(
                            'post_type' => 'product',
                            'posts_per_page'  => 12,
                            'product_cat'   =>  'music',
                            'orderby' => 'ASC' 
                          ); ?>

                    <?php $loop_music = new WP_Query( $music ); ?>
                    <?php while ($loop_music->have_posts()): $loop_music->the_post(); ?>
                      <div class="item item-carousel">
                        <div class="products">
                          <div class="product">
                          
                            <a href="<?php echo get_permalink( $loop_music->post->ID ) ?>" title="<?php echo esc_attr($loop_music->post->post_title ? $loop_music->post->post_title : $loop_music->post->ID); ?>"> 

                              <div class="product-image">
                                <div class="image">
                              <?php if( has_post_thumbnail( $loop_music->post->ID ))
                                      echo get_the_post_thumbnail( $loop_music->post->ID , 'shop_catalog' ); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" />'; ?>
                                </div>

                                <?php
                                $sale_price = $product->get_sale_price();
                                if (!empty($sale_price)): ?>
                                <div class="tag sale">
                                  <span>
                                  <?php woocommerce_show_product_sale_flash( $post, $product ); ?>
                                  </span>
                                </div>
                                <?php endif; ?>
                              </div>
                              <div class="product-info text-left">
                                <h3 class="name"><?php the_title(); ?></h3>
                                <div class="rating rateit-small"></div>
                                <div class="description"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  <?php echo $product ->get_regular_price(); ?>				</span>
                                  <span class="price-before-discount">
                                    <?php if( $product->is_on_sale() ) {
                                      echo $product->get_sale_price(); 
                                    }?>
                                  </span>
                                </div>
                              </div>
                            </a>
                            <?php woocommerce_template_loop_add_to_cart( $loop_music->post, $product ); ?>
                          </div>
                        </div>
                      </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                    </div>
                  </div>
                </div>
                
                <div class="tab-pane" id="laptop">
                  <div class="product-slider">
                    <div class="owl-carousel home-owl-carousel custom-carousel owl-theme">
                    
                    <?php 
                      
                      $tshirts = array(
                        'post_type' =>  'product',
                        'post_per_page' => 12,
                        'product_cat' =>  'tshirts',
                        'orderby' =>  'ASC'
                      );
                      $loop_tshirts = new WP_Query( $tshirts );
                      while($loop_tshirts->have_posts()): $loop_tshirts->the_post();
                    ?>
                      <div class="item item-carousel">
                        <div class="products">
                          <div class="product">
                            <a href="<?php echo get_permalink($loop_tshirts->post->ID) ?>" title="<?php echo esc_attr($loop_tshirts->post->the_title ? $loop_tshirts->post->the_title : $loop_tshirts->post->ID); ?>">

                              <div class="product-image">
                                <div class="image">
                                  <?php 
                                    if( has_post_thumbnail($loop_tshirts->post->ID) )
                                      echo get_the_post_thumbnail($loop_tshirts->post->ID, 'shop_catalog');
                                    else
                                      echo '<img src="'. woocommerce_placeholder_img_src() .'" alt="placeholder" />';
                                   ?>
                                </div>
                                <?php 
                                $sale_price = $product->get_sale_price();
                                if (!empty($sale_price)): ?>
                                <div class="tag new">
                                  <span>
                                <?php woocommerce_show_product_sale_flash($post,$product); ?>
                                  </span>
                                </div>
                              <?php endif; ?>
                              </div>
                              <div class="product-info text-left">
                                <h3 class="name"><?php the_title(); ?></h3>
                                <div class="rating rateit-small"></div>
                                <div class="description"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  <?php echo $product->get_regular_price(); ?>				</span>
                                  <span class="price-before-discount">
                                    <?php if ( $product->is_on_sale() )
                                    echo $product->get_sale_price(); ?>
                                  </span>
                                </div>
                              </div>
                            </a>
                            <?php woocommerce_template_loop_add_to_cart( $loop_music->post, $product ); ?>
                          </div>
                        </div>
                      </div>
                      
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>

                    </div>
                  </div>
                </div>


                <div class="tab-pane" id="apple">
                  <div class="product-slider">
                    <div class="owl-carousel home-owl-carousel custom-carousel owl-theme">
                      
                      <?php 

                      $shoes = array(
                              'post_per_page' => 12,
                              'post_type' => 'product',
                              'product_cat' => $shoes_i,
                              'orderby' =>  'ASC',
                            ); 
                      $loop_shoes = new WP_Query( $shoes );

                      while( $loop_shoes->have_posts() ): $loop_shoes->the_post(); ?>

                      <div class="item item-carousel">
                        <div class="products">
                          <div class="product">

                            <a href="<?php echo get_permalink() ?>" title="<?php echo get_the_title()?>">

                              <div class="product-image">
                                <div class="image">
                                  <?php 

                                    if( has_post_thumbnail($loop_shoes->post->ID) )
                                      echo get_the_post_thumbnail($loop_shoes->post->ID, 'shop_catalog');
                                    else 
                                      echo "<img src=". woocommerce_placeholder_img_src() ." alt='placeholder' />";
                                   ?>
                                </div>
                              <?php 
                              $sale_price = $product->get_sale_price();
                              if (!empty($sale_price)): ?>
                                <div class="tag sale">
                                  <span>
                                  <?php woocommerce_show_product_sale_flash($post,$product); ?>
                                  </span>
                                </div>
                              <?php endif;  ?>
                              </div>
                              <div class="product-info text-left">
                                <h3 class="name"><?php the_title(); ?></h3>
                                <div class="rating rateit-small"></div>
                                <div class="description"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  <?php echo $product->get_regular_price(); ?>				</span>
                                  <span class="price-before-discount">
                                    <?php if ( $product->is_on_sale() )
                                    echo $product->get_sale_price(); ?>
                                  </span>
                                </div>
                              </div>

                            </a>
                            <?php woocommerce_template_loop_add_to_cart( $loop_shoes->post, $product ); ?>
                          </div>
                        </div>
                      </div>

                      <?php endwhile; ?>
                      <?php wp_reset_query(); ?>

                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--  WIDE PRODUCTS  -->
            <div class="wide-banners wow fadeInUp outer-bottom-xs">
              <div class="row">
                <div class="col-md-7 col-sm-7">
                  <div class="wide-banner cnt-strip">
                    <div class="image">
                      <img class="img-responsive" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/banners/home-banner1.jpg" alt="">
                    </div>
                  </div>
                </div>
                <div class="col-md-5 col-sm-5">
                  <div class="wide-banner cnt-strip">
                    <div class="image">
                      <img class="img-responsive" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/banners/home-banner2.jpg" alt="">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- FEATURED PRODUCTS  -->
            <section class="section featured-product wow fadeInUp">
              <h3 class="section-title">Featured products</h3>
              <div class="owl-carousel home-owl-carousel custom-carousel owl-theme outer-top-xs">
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p5.jpg" alt=""></a>
                        </div>
                        <div class="tag hot"><span>hot</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p6.jpg" alt=""></a>
                        </div>
                        <div class="tag new"><span>new</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p7.jpg" alt=""></a>
                        </div>
                        <div class="tag sale"><span>sale</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p8.jpg" alt=""></a>
                        </div>
                        <div class="tag hot"><span>hot</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p9.jpg" alt=""></a>
                        </div>
                        <div class="tag new"><span>new</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p10.jpg" alt=""></a>
                        </div>
                        <div class="tag sale"><span>sale</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            <!--  WIDE PRODUCTS -->
            <div class="wide-banners wow fadeInUp outer-bottom-xs">
              <div class="row">
                <div class="col-md-12">
                  <div class="wide-banner cnt-strip">
                    <div class="image">
                      <img class="img-responsive" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/banners/home-banner.jpg" alt="">
                    </div>
                    <div class="strip strip-text">
                      <div class="strip-inner">
                        <h2 class="text-right">New Mens Fashion<br>
                          <span class="shopping-needs">Save up to 40% off</span>
                        </h2>
                      </div>
                    </div>
                    <div class="new-label">
                      <div class="text">NEW</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- BEST SELLER  -->
            <div class="best-deal wow fadeInUp outer-bottom-xs">
              <h3 class="section-title">Best seller</h3>
              <div class="sidebar-widget-body outer-top-xs">
                <div class="owl-carousel best-seller custom-carousel owl-theme outer-top-xs">
                  <div class="item">
                    <div class="products best-product">
                      <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="#">
                                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p20.jpg" alt="">
                                  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col2 col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                                <div class="rating rateit-small"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  $450.99				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="#">
                                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p21.jpg" alt="">
                                  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col2 col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                                <div class="rating rateit-small"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  $450.99				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="products best-product">
                      <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="#">
                                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p22.jpg" alt="">
                                  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col2 col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                                <div class="rating rateit-small"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  $450.99				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="#">
                                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p23.jpg" alt="">
                                  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col2 col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                                <div class="rating rateit-small"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  $450.99				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="products best-product">
                      <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="#">
                                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p24.jpg" alt="">
                                  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col2 col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                                <div class="rating rateit-small"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  $450.99				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="#">
                                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p25.jpg" alt="">
                                  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col2 col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                                <div class="rating rateit-small"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  $450.99				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="products best-product">
                      <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="#">
                                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p26.jpg" alt="">
                                  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col2 col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                                <div class="rating rateit-small"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  $450.99				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="#">
                                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p27.jpg" alt="">
                                  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col2 col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                                <div class="rating rateit-small"></div>
                                <div class="product-price">	
                                  <span class="price">
                                  $450.99				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--  BLOG SLIDER  -->
            <section class="section latest-blog outer-bottom-vs wow fadeInUp">
              <h3 class="section-title">latest form blog</h3>
              <div class="blog-slider-container outer-top-xs">
                <div class="owl-carousel blog-slider custom-carousel">
                   
            <?php $blog_post = array(
                    'post_type' => 'post',
                    'post_per_page' => 12,
                  );

                  $loop_blog = new WP_Query( $blog_post );

                  if($loop_blog->have_posts()):
                    while($loop_blog->have_posts()): $loop_blog->the_post(); ?>

                  <div class="item">
                    <div class="blog-post">
                      <div class="blog-post-image">
                        <div class="image">
                          <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail('post-thumbnail', ['class' => 'img-responsive responsive--full', 'title' => 'Feature image']); ?>
                          </a>
                        </div>
                      </div>
                      <div class="blog-post-info text-left">
                        <h3 class="name"><a href="#"><?php the_title(); ?></a></h3>
                        <span class="info"><?php the_author(); ?> &nbsp;|&nbsp; <?php echo get_the_date('F j, Y'); ?> </span>
                        <p class="text"><?php read_more("40") ?>...</p>
                        <a href="<?php the_permalink(); ?>" class="lnk btn btn-primary">Read more</a>
                      </div>
                    </div>
                  </div>
                <?php endwhile; endif; ?>

                </div>
              </div>
            </section>
            <!-- FEATURED PRODUCTS  -->
            <section class="section wow fadeInUp new-arriavls">
              <h3 class="section-title">New Arrivals</h3>
              <div class="owl-carousel home-owl-carousel custom-carousel owl-theme outer-top-xs">
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p19.jpg" alt=""></a>
                        </div>
                        <div class="tag new"><span>new</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p28.jpg" alt=""></a>
                        </div>
                        <div class="tag new"><span>new</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p30.jpg" alt=""></a>
                        </div>
                        <div class="tag hot"><span>hot</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p1.jpg" alt=""></a>
                        </div>
                        <div class="tag hot"><span>hot</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p2.jpg" alt=""></a>
                        </div>
                        <div class="tag sale"><span>sale</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item item-carousel">
                  <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="detail.html"><img  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/products/p3.jpg" alt=""></a>
                        </div>
                        <div class="tag sale"><span>sale</span></div>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="detail.html">Floral Print Buttoned</a></h3>
                        <div class="rating rateit-small"></div>
                        <div class="description"></div>
                        <div class="product-price">	
                          <span class="price">
                          $450.99				</span>
                          <span class="price-before-discount">$ 800</span>
                        </div>
                      </div>
                      <div class="cart clearfix animate-effect">
                        <div class="action">
                          <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                              <button class="btn btn-primary icon" data-toggle="dropdown" type="button">
                              <i class="fa fa-shopping-cart"></i>													
                              </button>
                              <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                            </li>
                            <li class="lnk wishlist">
                              <a class="add-to-cart" href="detail.html" title="Wishlist">
                              <i class="icon fa fa-heart"></i>
                              </a>
                            </li>
                            <li class="lnk">
                              <a class="add-to-cart" href="detail.html" title="Compare">
                              <i class="fa fa-signal" aria-hidden="true"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
        <div id="brands-carousel" class="logo-slider wow fadeInUp">
          <div class="logo-slider-inner">
            <div id="brand-slider" class="owl-carousel brand-slider custom-carousel owl-theme">
              <div class="item m-t-15">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand1.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item m-t-10">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand2.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand3.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand5.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand6.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand2.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand1.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/brands/brand5.png" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/blank.gif" alt="">
                </a>	
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php get_footer();?>