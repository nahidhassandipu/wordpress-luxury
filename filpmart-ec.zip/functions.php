<?php

//*** Support Title Tag 
add_theme_support( 'title-tag' );

//*** Enqueue FlipMart Scripts
function flipmart_enqueue_scripts(){
	
	wp_enqueue_style( 'bootstrap', get_template_directory_uri().'/assets/css/bootstrap.min.css', array(), '3.2.0' );
		
	wp_enqueue_style( 'main', get_template_directory_uri().'/assets/css/main.css', array(), '1.0' );
	
	wp_enqueue_style( 'blue', get_template_directory_uri().'/assets/css/blue.css', array(), '1.0' );
	
	wp_enqueue_style( 'owl.carousel', get_template_directory_uri().'/assets/css/owl.carousel.css', array(), '1.0' );
	
	wp_enqueue_style( 'owl.transitions', get_template_directory_uri().'/assets/css/owl.transitions.css', array(), '1.0' );
	
	wp_enqueue_style( 'animate.min', get_template_directory_uri().'/assets/css/animate.min.css', array(), '1.0' );
	
	wp_enqueue_style( 'rateit', get_template_directory_uri().'/assets/css/rateit.css', array(), '1.0' );
	
	wp_enqueue_style( 'bootstrap-select.min', get_template_directory_uri().'/assets/css/bootstrap-select.min.css', array(), '1.0' );
	
	wp_enqueue_style( 'font-awesome', get_template_directory_uri().'/assets/css/font-awesome.css', array(), '1.0' );
	
	// Theme stylesheet.
	wp_enqueue_style( 'style', get_stylesheet_uri() );
	
	// WP Latest JQuery
	wp_enqueue_script( 'jquery' );
	
	wp_enqueue_script( 'bootstrap.min', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'bootstrap-hover-dropdown.min', get_template_directory_uri() . '/assets/js/bootstrap-hover-dropdown.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'owl.carousel.min', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'echo.min', get_template_directory_uri() . '/assets/js/echo.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'jquery.easing', get_template_directory_uri() . '/assets/js/jquery.easing-1.3.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'bootstrap-slider.min', get_template_directory_uri() . '/assets/js/bootstrap-slider.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'lightbox.min', get_template_directory_uri() . '/assets/js/lightbox.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'bootstrap-select.min', get_template_directory_uri() . '/assets/js/bootstrap-select.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'bootstrap-select.min', get_template_directory_uri() . '/assets/js/bootstrap-select.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'wow.min', get_template_directory_uri() . '/assets/js/wow.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'scripts', get_template_directory_uri() . '/assets/js/scripts.js', array(), '1.0.0', true );
	

}

add_action('wp_enqueue_scripts','flipmart_enqueue_scripts');


// WooCommerce Theme Support 

add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

function mytheme_add_woocommerce_support() {
	add_theme_support( 'woocommerce', array(
		'thumbnail_image_width' => 220,
		'single_image_width'    => 300,

        'product_grid'          => array(
            'default_rows'    => 3,
            'min_rows'        => 2,
            'max_rows'        => 8,
            'default_columns' => 4,
            'min_columns'     => 2,
            'max_columns'     => 5,
        ),
	) );
}
add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );

/**
 * Change number or products per row to 3
 */
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		return 3; // 3 products per row
	}
}


add_filter( 'woocommerce_product_add_to_cart_text' , 'custom_woocommerce_product_add_to_cart_text' );
/**
 * custom_woocommerce_template_loop_add_to_cart
*/
function custom_woocommerce_product_add_to_cart_text() {
	global $product;
	
	$product_type = $product->product_type;
	
	// if (!is_front_page()) {
		
		switch ( $product_type ) {
			case 'external':
				return __( 'Buy product', 'woocommerce' );
			break;
			case 'grouped':
				return __( 'View products', 'woocommerce' );
			break;
			case 'simple':
				return __( 'Add to cart', 'woocommerce' );
			break;
			case 'variable':
				return __( 'Select options', 'woocommerce' );
			break;
			default:
				return __( 'Read more', 'woocommerce' );
		}
	// }
	
}



$shoes_i = [];
$shoes_cats = ['shoes', 'ankle boots, ballerinas, brogues, calf boots, canvas shoes, chelsea boots, court shoes, flip flops, gladiator sandals, heels, lace ups, loafers, military boots, mules, trainers, wedges, wellington boots'];

foreach ($shoes_cats as $shoes_cat) {
	$shoes_i .= $shoes_cat;
}



add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_add_to_cart', 10 );
// Change woocommerce defaults breadcrumb
add_filter( 'woocommerce_breadcrumb_defaults', 'flipmart_woocommerce_breadcrumbs' );
function flipmart_woocommerce_breadcrumbs() {
    return array(
            'delimiter'   => ' &#47; ',
            'wrap_before' => '<div class="breadcrumb-inner">
          <ul class="list-inline list-unstyled">',
            'wrap_after'  => '</ul>
        </div>',
            'before'      => '',
            'after'       => '',
            'home'        => _x( 'Home', 'breadcrumb', 'woocommerce' ),
        );
}

// Remove woocommerce defaults breadcrumb
add_action( 'init', 'flipmart_remove_wc_breadcrumbs' );
function flipmart_remove_wc_breadcrumbs() {
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}
// Remove woocommerce defaults result count
add_action( 'init', 'flipmart_woocommerce_result_count' );
function flipmart_woocommerce_result_count() {
    remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20, 0 );
}

// Remove woocommerce defaults catalog ordering
add_action( 'init', 'flipmart_woocommerce_catalog_ordering' );
function flipmart_woocommerce_catalog_ordering() {
    remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30, 0 );
}

// Remove woocommerce defaults pagination
add_action( 'init', 'flipmart_woocommerce_pagination' );
function flipmart_woocommerce_pagination() {
    remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10, 0 );
}

function flipmart_pagination() {

global $wp_query;

$big = 999999999; // need an unlikely integer

$pages = paginate_links( array(
        'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
        'format' => '?paged=%#%',
        'current' => max( 1, get_query_var('paged') ),
        'total' => $wp_query->max_num_pages,
        'type'  => 'array',
		'prev_next'          => true,
		'prev_text'          => __('<i class="fa fa-angle-left"></i>'),
		'next_text'          => __('<i class="fa fa-angle-right"></i>'),

    ) );
    if( is_array( $pages ) ) {
        $paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
        echo '<div class="pagination-container"><ul class="list-inline list-unstyled">';
        foreach ( $pages as $page ) {
                echo "<li>$page</li>";
        }
       echo '</ul></div>';
        }
}


function read_more($limit) {
	$exploding = explode(" ", get_the_content());
	$slicing = array_slice($exploding, 0, $limit);
	echo implode(" ", $slicing);
}



function theme_support() {
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
	) );
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );
	register_nav_menus(
		array(
			'header-top-menu'	=>	'Header Top Menu',
			'header-bottom-menu'	=>	'Header Bottom Menu',
			'footer-menu'	=>	'Footer Menu',
		)
	);
}
add_action( 'after_setup_theme', 'theme_support' );

