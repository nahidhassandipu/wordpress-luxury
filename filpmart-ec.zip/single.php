<?php get_header(); ?>
    <div class="breadcrumb">
      <div class="container">
        <div class="breadcrumb-inner">
          <ul class="list-inline list-unstyled">
            <li><a href="#">Home</a></li>
            <li class='active'>Blog</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="body-content">
      <div class="container">
        <div class="row">
          <div class="blog-page">
            <div class="col-md-9">
              <?php if(have_posts()):
                    while(have_posts()): the_post(); ?>
              <div class="blog-post outer-top-bd wow fadeInUp">
 
                  <?php the_post_thumbnail('post-thumbnail', ['class' => 'img-responsive responsive--full', 'title' => 'Feature image']); ?>
 
                <h1><a href="blog-details.html"><?php the_title(); ?></a></h1>
                <span class="author"><?php the_author(); ?></span>
                <span class="review"><?php echo get_comments_number($post->ID); ?></span>
                <span class="date-time"><?php the_date('d') ?> <?php the_time('M-y'); ?></span>
                <p><?php the_content(); ?></p>
              </div>
            <?php endwhile;
                else :
                    echo "<h1>Sorry dude there is no post</h1>";    
                endif; ?>

              <div class="clearfix blog-pagination filters-container  wow fadeInUp" style="padding:0px; background:none; box-shadow:none; margin-top:15px; border:none">
                <div class="text-right">
                  <div class="pagination-container">
                    <ul class="list-inline list-unstyled">
                      <li class="prev"><a href="#"><i class="fa fa-angle-left"></i></a></li>
                      <li><a href="#">1</a></li>
                      <li class="active"><a href="#">2</a></li>
                      <li><a href="#">3</a></li>
                      <li><a href="#">4</a></li>
                      <li class="next"><a href="#"><i class="fa fa-angle-right"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-3 sidebar">
              <div class="sidebar-module-container">
                <div class="search-area outer-bottom-small">
                  <form>
                    <div class="control-group">
                      <input placeholder="Type to search" class="search-field">
                      <a href="#" class="search-button"></a>   
                    </div>
                  </form>
                </div>
                <div class="home-banner outer-top-n outer-bottom-xs">
                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/banners/LHS-banner.jpg" alt="Image">
                </div>
                <div class="sidebar-widget outer-bottom-xs wow fadeInUp">
                  <h3 class="section-title">Category</h3>
                  <div class="sidebar-widget-body m-t-10">
                    <div class="accordion">
                      <div class="accordion-group">
                        <div class="accordion-heading">
                          <a href="#collapseOne" data-toggle="collapse" class="accordion-toggle collapsed">
                          Camera
                          </a>
                        </div>
                        <div class="accordion-body collapse" id="collapseOne" style="height: 0px;">
                          <div class="accordion-inner">
                            <ul>
                              <li><a href="#">gaming</a></li>
                              <li><a href="#">office</a></li>
                              <li><a href="#">kids</a></li>
                              <li><a href="#">for women</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-group">
                        <div class="accordion-heading">
                          <a href="#collapseTwo" data-toggle="collapse" class="accordion-toggle collapsed">
                          Desktops
                          </a>
                        </div>
                        <div class="accordion-body collapse" id="collapseTwo" style="height: 0px;">
                          <div class="accordion-inner">
                            <ul>
                              <li><a href="#">gaming</a></li>
                              <li><a href="#">office</a></li>
                              <li><a href="#">kids</a></li>
                              <li><a href="#">for women</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-group">
                        <div class="accordion-heading">
                          <a href="#collapseThree" data-toggle="collapse" class="accordion-toggle collapsed">
                          Pants
                          </a>
                        </div>
                        <div class="accordion-body collapse" id="collapseThree" style="height: 0px;">
                          <div class="accordion-inner">
                            <ul>
                              <li><a href="#">gaming</a></li>
                              <li><a href="#">office</a></li>
                              <li><a href="#">kids</a></li>
                              <li><a href="#">for women</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-group">
                        <div class="accordion-heading">
                          <a href="#collapseFour" data-toggle="collapse" class="accordion-toggle collapsed">
                          Bags
                          </a>
                        </div>
                        <div class="accordion-body collapse" id="collapseFour" style="height: 0px;">
                          <div class="accordion-inner">
                            <ul>
                              <li><a href="#">gaming</a></li>
                              <li><a href="#">office</a></li>
                              <li><a href="#">kids</a></li>
                              <li><a href="#">for women</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-group">
                        <div class="accordion-heading">
                          <a href="#collapseFive" data-toggle="collapse" class="accordion-toggle collapsed">
                          Hats
                          </a>
                        </div>
                        <div class="accordion-body collapse" id="collapseFive" style="height: 0px;">
                          <div class="accordion-inner">
                            <ul>
                              <li><a href="#">gaming</a></li>
                              <li><a href="#">office</a></li>
                              <li><a href="#">kids</a></li>
                              <li><a href="#">for women</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-group">
                        <div class="accordion-heading">
                          <a href="#collapseSix" data-toggle="collapse" class="accordion-toggle collapsed">
                          Accessories
                          </a>
                        </div>
                        <div class="accordion-body collapse" id="collapseSix" style="height: 0px;">
                          <div class="accordion-inner">
                            <ul>
                              <li><a href="#">gaming</a></li>
                              <li><a href="#">office</a></li>
                              <li><a href="#">kids</a></li>
                              <li><a href="#">for women</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="sidebar-widget outer-bottom-xs wow fadeInUp">
                  <h3 class="section-title">tab widget</h3>
                  <ul class="nav nav-tabs">
                    <li class="active"><a href="#popular" data-toggle="tab">popular post</a></li>
                    <li><a href="#recent" data-toggle="tab">recent post</a></li>
                  </ul>
                  <div class="tab-content" style="padding-left:0">
                    <div class="tab-pane active m-t-20" id="popular">
                      <div class="blog-post inner-bottom-30 " >
                        <img class="img-responsive" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blog-post/blog_big_01.jpg" alt="">
                        <h4><a href="blog-details.html">Simple Blog Post</a></h4>
                        <span class="review">6 Comments</span>
                        <span class="date-time">12/06/16</span>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                      </div>
                      <div class="blog-post" >
                        <img class="img-responsive" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blog-post/blog_big_02.jpg" alt="">
                        <h4><a href="blog-details.html">Simple Blog Post</a></h4>
                        <span class="review">6 Comments</span>
                        <span class="date-time">23/06/16</span>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                      </div>
                    </div>
                    <div class="tab-pane m-t-20" id="recent">
                      <div class="blog-post inner-bottom-30" >
                        <img class="img-responsive" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blog-post/blog_big_03.jpg" alt="">
                        <h4><a href="blog-details.html">Simple Blog Post</a></h4>
                        <span class="review">6 Comments</span>
                        <span class="date-time">5/06/16</span>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                      </div>
                      <div class="blog-post">
                        <img class="img-responsive" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blog-post/blog_big_01.jpg" alt="">
                        <h4><a href="blog-details.html">Simple Blog Post</a></h4>
                        <span class="review">6 Comments</span>
                        <span class="date-time">10/07/16</span>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="sidebar-widget product-tag wow fadeInUp">
                  <h3 class="section-title">Product tags</h3>
                  <div class="sidebar-widget-body outer-top-xs">
                    <div class="tag-list">					
                      <a class="item" title="Phone" href="category.html">Phone</a>
                      <a class="item active" title="Vest" href="category.html">Vest</a>
                      <a class="item" title="Smartphone" href="category.html">Smartphone</a>
                      <a class="item" title="Furniture" href="category.html">Furniture</a>
                      <a class="item" title="T-shirt" href="category.html">T-shirt</a>
                      <a class="item" title="Sweatpants" href="category.html">Sweatpants</a>
                      <a class="item" title="Sneaker" href="category.html">Sneaker</a>
                      <a class="item" title="Toys" href="category.html">Toys</a>
                      <a class="item" title="Rose" href="category.html">Rose</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="brands-carousel" class="logo-slider wow fadeInUp">
          <div class="logo-slider-inner">
            <div id="brand-slider" class="owl-carousel brand-slider custom-carousel owl-theme">
              <div class="item m-t-15">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item m-t-10">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
              <div class="item">
                <a href="#" class="image">
                <img data-echo="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/brand4.png" src="<?php echo esc_url(get_template_directory_uri()); ?>assets/images/blank.gif" alt="">
                </a>	
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php get_footer(); ?>