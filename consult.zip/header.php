<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "id=header" header.
 *
 * @since consult 1.0
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> lang="en">
<head>
    
    <meta charset="utf-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    
    <title><?php single_post_title(); ?></title>


    <?php wp_head(); ?>
    <?php global $redux_demo; ?>
</head>
<body <?php body_class(); ?>>
    <!--Start Preloader-->
    <div class="preloader">
        <div class="preloader-inner-area">
            <div class="loader-overlay">
                <div class="l-preloader">
                    <div class="c-preloader"></div>
                </div>
            </div>
        </div>
    </div> 
    <!--End Preloader-->
    
    <header id="header" class="header_areaa">
        <nav class="navbar extended">
            <div class="nav-wrapper dark-wrapper inverse-text">
                <div class="container flex-it">
                    <div class="navbar-collapse collapse align-left">
                        <?php    
				            $arge = array(
				                'theme_location' => 'primary',
				                'menu_class'	=> 'nav navbar-nav',
				                'container'	=> '',
				                
				            );   
				            wp_nav_menu($arge);
				        ?>
                    </div>
                    <div class="navbar-other">
                        <div class="align-right text-right">
                            <div class="navbar-brand">
								<a href="<?php $url = home_url(); echo esc_url( $url ); ?>">
						<img alt="images" src="<?php echo $redux_demo['logo_upload']['url']; ?>">
								</a>
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header><!-- /header -->


    