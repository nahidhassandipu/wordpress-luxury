<style>
    .faqs_title_bg {
        background: url('<?php echo to_get_featured_image();?>') no-repeat scroll center center;
    }
</style>
<?php
/*

Template Name: Contact Page

*/
?>
<?php get_header(); ?>

    
    <div class="page_title_banner faqs_title_bg">
        <div class="page_title_banner_overlay"></div>
        <div class="container">
            <div class="page_title_banner_text text-center">
                <?php the_title( '<h2 class="entry-title banner_effect">', '</h2>' ); ?>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Pages</a></li>
                    <li class="active"><?php the_title(); ?></li>
                </ul>
            </div>
        </div><!--container-->
    </div><!--page_title_banner-->

<?php global $redux_demo;  ?>
    
    <div style="width: 100%;position: relative;">
        <iframe style="width:100%;height:440px" src="https://maps.google.com/maps?width=700&amp;height=440&amp;hl=en&amp;q=burj%20khalifa+(Title)&amp;ie=UTF8&amp;t=&amp;z=10&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0">
        </iframe>
    </div>

    
    <div class="container-fluid">
        <div class="row">
            <div id="contact-form-contain-id" class="col-xs-12">
                <?php dynamic_sidebar('contact_page_form'); ?>
            </div>
        </div>
    </div>
    
    <div id="home1_newsletter">
        <div class="container">
            <div class="home1_newsletter">
                <div class="row">
                    <?php dynamic_sidebar('contact_page_subscription'); ?>
                </div>
            </div><!--home1_newsletter-->
        </div><!--container-->
    </div><!--home1_newsletter-->
    
    <script>
        jQuery(document).ready(function($){
            $('.es_textbox #es_txt_email').attr('placeholder', 'Enter Your Email');
        });
    </script>
            
<?php get_footer(); ?>