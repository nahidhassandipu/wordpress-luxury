 
    <footer class="footer_area">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="footer_widget">
                        <h4 class="widget_title">
                            <?php global $redux_demo; echo $redux_demo['Headquarters_title'] ?>
                        </h4>
                        <div class="footer_widget_content para_default">
                            <ul class="contact_info">
                                <li>
                                    <span class="icon flaticon-phone-call"></span>
                                    <?php echo $redux_demo['phone_number'] ?>
                                </li>
                                <li><span class="icon flaticon-contact"></span>
                                    <?php echo $redux_demo['email_consult'] ?></li>
                                <li><span class="icon flaticon-placeholder-outline"></span>
                                    <?php echo $redux_demo['consult_address'] ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="footer_widget">
                        <h4 class="widget_title">Company Title</h4>
                        <div class="footer_widget_content para_default">
                            <?php 
                                $arge = array(
                                    'theme_location' => 'footer_menus'
                                );
                                wp_nav_menu($arge);
                             ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="footer_widget">
                        <h4 class="widget_title">Useful Link</h4>
                        <div class="footer_widget_content para_default">
                            <?php 
                                $arge = array(
                                    'theme_location' => 'usefull_links'
                                );
                                wp_nav_menu($arge);

                             ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="footer_widget">
                        <h4 class="widget_title"><?php echo $redux_demo['newsletter_title'] ?></h4>
                        <div class="footer_widget_content para_default">
                            <p><?php echo $redux_demo['newsletter_textarea'] ?></p>
                            <div class="Newsletter_mail_search">
                                <?php dynamic_sidebar('footer_page_subscription'); ?>
                            </div>
                            <ul class="footer_social_icon">
                                <?php if($redux_demo['facebook_link'] != null) { ?>
                                <li>
                                    <a href="<?php echo $redux_demo['facebook_link'] ?>"><i class="fa fa-facebook"></i></a>
                                </li><?php } ?>
                                <?php if($redux_demo['twitter_links'] != null) { ?>
                                <li>
                                    <a href="<?php echo $redux_demo['twitter_links'] ?>"><i class="fa fa-twitter"></i></a>
                                </li><?php } ?>
                                <?php if($redux_demo['pinterest_link'] != null) { ?>
                                <li>
                                    <a href="<?php echo $redux_demo['pinterest_link'] ?>"><i class="fa fa-pinterest-p"></i></a>
                                </li><?php } ?>
                                <?php if($redux_demo['youtube_link'] != null) { ?>
                                <li>
                                    <a href="<?php echo $redux_demo['youtube_link'] ?>"><i class="fa fa-youtube"></i></a>
                                </li><?php } ?>
                                <?php if($redux_demo['google_link'] != null) { ?>
                                <li>
                                    <a href="<?php echo $redux_demo['google_link'] ?>"><i class="fa fa-google"></i></a>
                                </li><?php } ?>
                                <?php if($redux_demo['linkedin_link'] != null) { ?>
                                <li>
                                    <a href="<?php echo $redux_demo['linkedin_link'] ?>"><i class="fa fa-linkedin"></i></a>
                                </li><?php } ?>
                                <?php if($redux_demo['instagram_link'] != null) { ?>
                                <li>
                                    <a href="<?php echo $redux_demo['instagram_link'] ?>"><i class="fa fa-instagram"></i></a>
                                </li><?php } ?>
                                <?php if($redux_demo['snapchat-ghost_link'] != null) { ?>
                                <li>
                                    <a href="<?php echo $redux_demo['snapchat-ghost_link'] ?>"><i class="fa fa-snapchat-ghost"></i></a>
                                </li><?php } ?>
                                <?php if($redux_demo['skype_link'] != null) { ?>
                                <li>
                                    <a href="<?php echo $redux_demo['skype_link'] ?>"><i class="fa fa-skype"></i></a>
                                </li><?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer_bottom text-center">
            <div style="color: white;" class="container">
                <p><?php echo $redux_demo['copyrigh_text']; ?></p>
            </div>
        </div>
    </footer>
    <script>
        jQuery(document).ready(function($){
            $('#es_txt_email').attr('placeholder', 'Enter Your Email')
        })
    </script>
    <?php wp_footer(); ?>
</body>
</html>