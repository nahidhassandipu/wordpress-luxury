<?php get_header(); ?>


<?php

	if(have_posts()):
		while(have_posts()): the_post(); ?>    
        <div class="container">
            <div style="margin: 50px 0" class="row">
                <div class="col-sm-6 services_image_container">
                    <?php the_post_thumbnail(); ?>
                </div>
                <div class="col-sm-6">
                    <h3><b><?php the_title(); ?></b></h3>
                    <p><?php the_content(); ?></p>
                </div>
            </div><!--row -->
            <div class="col-xs-12 services-block-post">
                <?php previous_post_link( $format = '&laquo;  %link',  $link = 'PREV'); ?>
    	        <?php next_post_link($format = '%link  &raquo;', $link = 'NEXT'); ?>
            </div>
        </div><!--container -->
        <?php endwhile; ?>
    <?php endif; ?>
		
<?php get_footer(); ?>