<?php get_header(); ?>

<?php 
    
    /*

    Template Name: Consult Blog

    */

 ?>
    <div class="page_title_banner blog_sidebar_title_bg">
        <div class="page_title_banner_overlay"></div>
        <div class="container">
            <div class="page_title_banner_text text-center">
                <h2 class="banner_effect">Blog</h2>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Pages</a></li>
                    <li class="active">Blog</li>
                </ul>
            </div>
        </div><!--container-->
    </div><!-- page_title_banner -->

    <div class="blog_page_area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="blog_left_side_area">

          <?php if(have_posts()):
                    while(have_posts()): the_post(); ?>
                        <div class="blog_left_single_item">
                            <div class="blog_pic image_fulwidth">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail(); ?>
                                </a>
                                <h4 class="date_position">
                                    <?php the_date('d') ?> <?php the_time('M-y'); ?>
                                </h4>
                            </div>
                            <div class="blog_left_single_content para_default">
                                <h3>
                                    <a href="<?php the_permalink(); ?> ">
                                        <?php the_title(); ?>
                                    </a>
                                </h3>
                                <p><?php read_more("40"); ?>...  
                                    <a href="<?php the_permalink(); ?>">
                                        <button class="btn btn-lg">Read More</button>
                                    </a>
                                </p>
                            </div>
                        </div><!-- blog_left_single_item <-->
                            <hr>
                        </-->
              <?php endwhile;
                else :
                    echo "<h1>Sorry dude there is no post</h1>";    
                endif; ?>

                        <div class="blog_pagination">
                            <nav>
                                <?php the_posts_pagination( array(
                                    'prev_text' => __( '<i class="fas fa-arrow-left"></i>', 'consult' ),
                                    'next_text' => __( '<i class="fas fa-arrow-right"></i>', 'consult' ),
                                    'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'consult' ) . ' </span>',
                                ) ); ?>
                                <!-- <ul class="pagination pagination-lg">
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>

                                    <li class="page-item">
                                        <a class="page-link" href="#"><i class="flaticon-right-arrow"></i></a>
                                    </li>
                                </ul> -->
                            </nav>
                        </div>
                    </div><!-- blog_left_side_area -->
                </div><!-- col-md-8 -->
                <div class="col-md-4">
                    <?php get_sidebar(); ?>
                </div><!-- col-md-4 -->
            </div><!-- row -->
        </div><!-- container -->
    </div><!-- blog_page_area -->

<?php get_footer(); ?>