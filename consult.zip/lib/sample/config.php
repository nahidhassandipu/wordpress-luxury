<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "redux_demo";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

        global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
    }

    // Background Patterns Reader
    $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
    $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
    $sample_patterns      = array();
    
    if ( is_dir( $sample_patterns_path ) ) {

        if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
            $sample_patterns = array();

            while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                    $name              = explode( '.', $sample_patterns_file );
                    $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                    $sample_patterns[] = array(
                        'alt' => $name,
                        'img' => $sample_patterns_url . $sample_patterns_file
                    );
                }
            }
        }
    }

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Consult', 'consult' ),
        'page_title'           => __( 'Consult', 'consult' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => 2,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
    $args['admin_bar_links'][] = array(
        'id'    => 'redux-docs',
        'href'  => 'http://docs.reduxframework.com/',
        'title' => __( 'Documentation', 'consult' ),
    );

    $args['admin_bar_links'][] = array(
        //'id'    => 'redux-support',
        'href'  => 'https://github.com/ReduxFramework/redux-framework/issues',
        'title' => __( 'Support', 'consult' ),
    );

    $args['admin_bar_links'][] = array(
        'id'    => 'redux-extensions',
        'href'  => 'reduxframework.com/extensions',
        'title' => __( 'Extensions', 'consult' ),
    );

    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( __( '', 'consult' ), $v );
    } else {
        $args['intro_text'] = __( '', 'consult' );
    }

    // Add content after the form.
    $args['footer_text'] = __( '', 'consult' );

    Redux::setArgs( $opt_name, $args );


    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'consult' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'consult' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'consult' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'consult' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'consult' );
    Redux::setHelpSidebar( $opt_name, $content );


    Redux::setSection($opt_name, array(
        'title'     => __('Home Page', 'consult'),
        'id'        => 'header_option',
        'icon'      => 'el el-website',
    ) );
    Redux::setSection($opt_name, array(
        'title' => 'About Company',
        'subsection'    => true,
        'id'    => 'subsection_home_1',
        'fields'    => array(
            array(
                'title'     => __( 'Logo Upload', 'consult' ),
                'subtitle'  => __( 'Upload your company\'s logo', 'consult'),
                'id'        => 'logo_upload',
                'type'      => 'media', 
                'compiler'  => 'true',
                'url'      => true,
                'default'  => array( 'url' => 'consult/wp-content/uploads/2018/12/logo-2.png' ),
            ),
            array(
                'title'         => __('Title', 'consult'),
                'type'          => 'text',
                'id'            => 'Abouthomepage',
                'default' => __('About Company Title', 'consult'),
                'desc'  => __('Write a good title about your company\'s services', 'consult'),
            ),
            array(
                'id'=>'Abouthomepage_description',
                'type' => 'textarea',
                'title' => __('Short description of company - HTML Validated Custom', 'consult'), 
                'subtitle' => __('Custom HTML Allowed (wp_kses)', 'consult'),
                'desc'  => __('Write a good content about your company\'s services that will appear on home page', 'consult'),
                'validate' => 'html_custom',
                'default' => '<br />Some HTML is allowed in here.<br />',
                'allowed_html' => array(
                    'a' => array(
                        'href' => array(),
                        'title' => array()
                    ),
                    'br' => array(),
                    'em' => array(),
                    'strong' => array()
                ),
            ),
            array(
                'id'       => 'about-media-home',
                'type'     => 'media', 
                'url'      => true,
                'title'    => __('Image of company', 'consult'),
                'desc'     => __('Upload an image that will appear next to .', 'consult'),
                'subtitle' => __('Upload media using the WordPress native uploader', 'consult'),
                'default'  => array(
                    'url'=>'https://9yj8tmimjfnjwpya-zippykid.netdna-ssl.com/wp-content/uploads/2016/12/image-main.jpg'
                ),
            ),
        )
    )); 
    Redux::setSection($opt_name, array(
        'title' => 'Home slider',
        'subsection'    => true,
        'id'    => 'home_slider',
        'fields'    => array(
            array(
                'title'     => __( 'Slider Image 1', 'consult' ),
                'subtitle'  => __( 'Upload an image', 'consult'),
                'desc'      => __('Upload an image that will appear on the home page as first slider', 'consult'),
                'id'        => 'slider_image_1_home',
                'type'      => 'media', 
                'compiler'  => true,
                'default'   => array(
                    'url'   => get_template_directory_uri().'/images/slider_img_02.jpg',
                ),
            ),
            array(
                'title'     => __( 'Slider Image 2', 'consult' ),
                'type'          => 'media',
                'desc'      => __('Upload an image that will appear on the home page as 2nd slider', 'consult'),
                'subtitle'  => __( 'Upload an image', 'consult'),
                'compiler'  => true,
                'id'            => 'slider_image_2_home',
                'default' => __('About Company Title', 'consult'),
                'desc'  => __('Write a good title about your company\'s services', 'consult'),
                'default'   => array(
                    'url'   => get_template_directory_uri().'/images/slider_img_02.jpg',
                ),
            ),
            array(
                'id'=>'slider_image_1_text',
                'type' => 'text',
                'title' => __('Write a quote', 'consult'), 
                'subtitle' => __('Custom HTML Allowed (wp_kses)', 'consult'),
                'desc'  => __('Write a good quote for slider image 1 that will appear on image', 'consult'),
                'validate' => 'html_custom',
                'default' => '<br />Some HTML is allowed in here.<br />',
                'allowed_html' => array(
                    'a' => array(
                        'href' => array(),
                        'title' => array()
                    ),
                    'br' => array(),
                    'em' => array(),
                    'strong' => array()
                ),
            ),
            array(
                'id'=>'slider_image_2_text',
                'type' => 'text',
                'title' => __('Write a quote', 'consult'), 
                'subtitle' => __('Custom HTML Allowed (wp_kses)', 'consult'),
                'desc'  => __('Write a good quote for slider image 2 that will appear on image', 'consult'),
                'validate' => 'html_custom',
                'default' => '<br />Some HTML is allowed in here.<br />',
                'allowed_html' => array(
                    'a' => array(
                        'href' => array(),
                        'title' => array()
                    ),
                    'br' => array(),
                    'em' => array(),
                    'strong' => array()
                ),
            ),
        )
    )); 
    Redux::setSection($opt_name, array(
        'title'     => __( 'About Page', 'consult' ),
        'id'    =>  'about_us_page',
        'icon'  =>  'el el-group',
        'fields'    =>  array(
            array(
                'title'     =>  __('Add sections of about page', 'consult'),
                'id'        =>  'about_us_page_section',
                'subtitle'      =>  __('Add sections about your company\'s Mission, Vision, About Us, History etc You can add as many section as you want, with an image', 'consult'),
                'type'     => 'slides',
            ),
        )
    ));
    
    Redux::setSection($opt_name, array(
        'title'     => __( 'Portfolio Page', 'consult' ),
        'id'    =>  'portfolio_page',
        'icon'  =>  'el el-screen-alt',
    ));
    
    Redux::setSection($opt_name, array(
        'title'     => __( 'Consulting', 'consult' ),
        'id'    =>  'consulting_portfolio',
        'subsection'    =>  true,
        'fields'    =>  array(
            array(
                'id'  =>  'consulting_portfolio_title',
                'title' =>  __( 'Change default title', 'consult' ),
                'desc'  =>  __('You can change title of of portfolio', 'consult'),
                'type'  =>  'text',
                'default'   =>  'Consulting',
            ),
            array(
                'id'  =>  'consulting_portfolio_gallery',
                'title' =>  __( 'Add image', 'consult' ),
                'desc'  =>  __('You can upload as many image as you want', 'consult'),
                'type'  =>  'slides',
            ),
        ),
    ));
    
    Redux::setSection($opt_name, array(
        'title'     => __( 'Business', 'consult' ),
        'id'    =>  'business_portfolio',
        'subsection'    =>  true,
        'fields'    =>  array(
            array(
                'id'  =>  'business_portfolio_title',
                'title' =>  __( 'Change default title', 'consult' ),
                'desc'  =>  __('You can change title of of portfolio', 'consult'),
                'type'  =>  'text',
                'default'   =>  'Business',
            ),
            array(
                'id'  =>  'business_portfolio_gallery',
                'title' =>  __( 'Add image', 'consult' ),
                'desc'  =>  __('You can upload as many image as you want', 'consult'),
                'type'  =>  'slides',
            ),
        ),
    ));
    Redux::setSection($opt_name, array(
        'title'     => __( 'Finance', 'consult' ),
        'id'    =>  'finance_portfolio',
        'subsection'    =>  true,
        'fields'    =>  array(
            array(
                'id'  =>  'finance_portfolio_title',
                'title' =>  __( 'Change default title', 'consult' ),
                'desc'  =>  __('You can change title of of portfolio', 'consult'),
                'type'  =>  'text',
                'default'   =>  'Finance',
            ),
            array(
                'id'  =>  'finance_portfolio_gallery',
                'title' =>  __( 'Add image', 'consult' ),
                'desc'  =>  __('You can upload as many image as you want', 'consult'),
                'type'  =>  'slides',
            ),
        ),
    ));
    Redux::setSection($opt_name, array(
        'title'     => __( 'Marketing', 'consult' ),
        'id'    =>  'marketing_portfolio',
        'subsection'    =>  true,
        'fields'    =>  array(
            array(
                'id'  =>  'marketing_portfolio_title',
                'title' =>  __( 'Change default title', 'consult' ),
                'desc'  =>  __('You can change title of of portfolio', 'consult'),
                'type'  =>  'text',
                'default'   =>  'Marketing',
            ),
            array(
                'id'  =>  'marketing_portfolio_gallery',
                'title' =>  __( 'Add image', 'consult' ),
                'desc'  =>  __('You can upload as many image as you want', 'consult'),
                'type'  =>  'slides',
            ),
        ),
    ));
    
    
    Redux::setSection($opt_name, array(
        'title'     => __('Footer Option', 'consult'),
        'id'        => 'footer_option',
        'icon'      => 'el el-barcode',
    ));
    Redux::setSection($opt_name, array(
        'subsection' => true,
        'title' => 'Headquarters',
        'desc'  => 'Customize your footer section from here',
        'id' => 'Headquarters',
        'fields'    => array(
            array(
                'title' => 'Title',
                'id'    => 'Headquarters_title',
                'type'  => 'text',
                'default'   => 'Our Headquarters',
            ),
            array(
                'title' => 'Phone Number',
                'id'    => 'phone_number',
                'type'  => 'text',
                'default'   => '+088 212 386 5575',
            ),
            array(
                'title' => 'Email',
                'id'    => 'email_consult',
                'type'  => 'text',
                'default'   => 'helloxpart@gmail.com',
            ),
            array(
                'title' => 'Address',
                'id'    => 'consult_address',
                'type'  => 'text',
                'default'   => '1010 Avenue Of The MoonNew York, NY 10018 US.',
            ),
        ),
    ));

    Redux::setSection($opt_name, array(
        'subsection' => true,
        'title' => 'Newsletter',
        'desc'  => 'Fill this textarea with some good words',
        'id' => 'newsletter',
        'fields'    => array(
            array(
                'title' => 'Title',
                'id'    => 'newsletter_title',
                'type'  => 'text',
                'default'   => 'Newsletter',
            ),
            array(
                'title' => 'Newsletter Content',
                'subtitle' => 'Write some good content in few words',
                'id'    => 'newsletter_textarea',
                'type'  => 'textarea',
            ),
        ),
    ));

    Redux::setSection($opt_name, array(
        'subsection' => true,
        'title' => 'Social Links',
        'desc'  => 'Fill up with social media\'s link',
        'id' => 'social_links',
        'fields'    => array(
            array(
                'title' => 'Facebook',
                'id'    => 'facebook_link',
                'type'  => 'text',
            ),
            array(
                'title' => 'Twitter',
                'subtitle' => 'Provide a valid link',
                'id'    => 'twitter_links',
                'type'  => 'text',
            ),
            array(
                'title' => 'Pinterest',
                'subtitle' => 'Provide a valid link',
                'id'    => 'pinterest_link',
                'type'  => 'text',
            ),
            array( 
                'title' => 'Youtube',
                'subtitle' => 'Provide a valid link',
                'id'    => 'youtube_link',
                'type'  => 'text',
            ),
            array(
                'title' => 'Google',
                'subtitle' => 'Provide a valid link',
                'id'    => 'google_link',
                'type'  => 'text',
            ),
            array(
                'title' => 'Linkedin',
                'subtitle' => 'Provide a valid link',
                'id'    => 'linkedin_link',
                'type'  => 'text',
            ),
            array( 
                'title' => 'Instagram',
                'subtitle' => 'Provide a valid link',
                'id'    => 'instagram_link',
                'type'  => 'text',
            ),
            array(
                'title' => 'Snapchat',
                'subtitle' => 'Provide a valid link',
                'id'    => 'snapchat-ghost_link',
                'type'  => 'text',
            ),
            array( 
                'title' => 'Skype',
                'subtitle' => 'Provide a valid link',
                'id'    => 'skype_link',
                'type'  => 'text',
            ),
        ),
    ));

    Redux::setSection($opt_name, array(
        'subsection' => true,
        'title' => 'Copyrigh',
        'id' => 'copyrigh',
        'fields'    => array(
            array(
                'id'=>'copyrigh_text',
                'type' => 'textarea',
                'title' => __('HTML Validated Custom', 'consult'), 
                'subtitle' => __('Custom HTML Allowed (wp_kses)', 'consult'),
                'desc' => __('Write copyright', 'consult'),
                'validate' => 'html_custom',
                'default' => '<br />Some HTML is allowed in here.<br />',
                'allowed_html' => array(
                    'a' => array(
                        'href' => array(),
                        'title' => array()
                    ),
                    'br' => array(),
                    'em' => array(),
                    'strong' => array()
                ),
            ),
        ),
    ) );


    Redux::setSection( $opt_name, array(
        'title'      => __( 'Color Setting', 'consult' ),
        'desc'       => __( 'Change your website\'s color in gradient way', 'consult' ),
        'id'         => 'color-gradient',
        'fields'     => array(
            array(
                'id'            => 'opt-color-header',
                'type'          => 'color_gradient',
                'title'         => __( 'Header Gradient Color Option', 'consult' ),
                'subtitle'      => __('Only color validation can be done on this field type','consult'),
                'default'       => array(
                    'from'      => '#1e73be',
                    'to'        => '#00897e'
                )
            ),
            array(
                'id'            => 'opt-color-rgba',
                'type'          => 'color_rgba',
                'title'         => __( 'Color RGBA', 'consult' ),
                'subtitle'      => __( 'Gives you the RGBA color.', 'consult' ),
                'default'       => array(
                    'color'     => '#7e33dd',
                    'alpha'     => '.8'
                ),
                //'output'      => array( 'body' ),
                'mode'          => 'background',
                //'validate'    => 'colorrgba',
            ),
            array(
                'id'            => 'opt-link-color',
                'type'          => 'link_color',
                'title'         => __('Links Color Option', 'consult'),
                'subtitle'      => __('Only color validation can be done on this field type','consult'),
                //'regular'     => true, // Disable Regular Color
                //'hover'       => true, // Disable Hover Color
                //'active'      => true, // Disable Active Color
                //'visited'     => true,  // Enable Visited Color
                'default'       => array(
                    'regular'   => '#aaa',
                    'hover'     => '#bbb',
                    'active'    => '#ccc',
                )
            ),
            array(
                'id'            => 'opt-palette-color',
                'type'          => 'palette',
                'title'         => __( 'Palette Color Option', 'consult' ),
                'subtitle'      => __('Only color validation can be done on this field type','consult'),
                'default'       => 'red',
                'palettes'      => array(
                    'red'       => array(
                        '#ef9a9a',
                        '#f44336',
                        '#ff1744',
                    ),
                    'pink'      => array(
                        '#fce4ec',
                        '#f06292',
                        '#e91e63',
                        '#ad1457',
                        '#f50057',
                    ),
                    'cyan'      => array(
                        '#e0f7fa',
                        '#80deea',
                        '#26c6da',
                        '#0097a7',
                        '#00e5ff',
                    ),
                )
            ),
        )
    ) );



    Redux::setSection( $opt_name, array(
        'title'     => __('General Option', 'consult'),
        'icon'      => 'el-icon-tasks',
        'fields'    => array(
            array(
                'title'         => __('Website Layout', 'consult'),
                'type'          => 'image_select',
                'id'            => 'website_layout',
                'options'       => array(
                    '1'     =>  array(
                        'img'   => get_template_directory_uri().'/lib/ReduxCore/assets/img/1c.png', 
                    ),
                    '2'     =>  array(
                        'img'   => get_template_directory_uri().'/lib/ReduxCore/assets/img/2cl.png', 
                    ),
                    '3'     =>  array(
                        'img'   => get_template_directory_uri().'/lib/ReduxCore/assets/img/2cr.png', 
                    ),
                ),
                'default'       => '3',
            ),
        ),
    ) );

    Redux::setSection($opt_name, array(
        'title'     => 'Social Options',
        'id'        => 'social_options',
        'icon'      => 'fa fa-signal',
        'fields'    => array(
            array(
                'title'         => 'Social Links',
                'id'            => 'social_icons',
                'type'          => 'text',
                'options'       => array(
                    '1'         => 'facebook',
                    '2'         => 'twitter',
                    '3'         => 'Google Plus',
                    '4'         => 'App Store',
                    '5'         => 'Google Play',
                ),
            ),
        ),
    ));

    Redux::setSection($opt_name, array(
        'title'            => 'Project',
        'id'               => 'Project_imgas',
        'desc'             => 'Upload your projects image',
        'fields'           => array(
            array(
                'title'    => 'Project\'s images',
                'id'       => 'Project_imgas_for_sidebar',
                'type'     => 'slides',
            ),
        ), 
    ));


    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $field['msg']    = 'your custom error message';
                $return['error'] = $field;
            }

            if ( $warning == true ) {
                $field['msg']      = 'your custom warning message';
                $return['warning'] = $field;
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'consult' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'consult' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }

    /**
     * Removes the demo link and the notice of integrated demo from the redux-framework plugin
     */
    if ( ! function_exists( 'remove_demo' ) ) {
        function remove_demo() {
            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                remove_filter( 'plugin_row_meta', array(
                    ReduxFrameworkPlugin::instance(),
                    'plugin_metalinks'
                ), null, 2 );

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
            }
        }
    }

