<?php get_header(); ?>

    
    <div class="page_title_banner blog_sidebar_title_bg">
        <div class="page_title_banner_overlay"></div>
        <div class="container">
            <div class="page_title_banner_text text-center">
                <h2 class="banner_effect">Blog Sidebar</h2>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Pages</a></li>
                    <li class="active">Blog sidebar</li>
                </ul>
            </div>
        </div><!--container-->
    </div><!-- page_title_banner -->

    <div class="blog_page_area">
        <div class="container">
            <div class="row">
			
			
                <div class="col-md-8">
				
                    <div class="blog_left_side_area">
                        <div class="blog_left_single_item">
                            <div class="blog_pic image_fulwidth">
                                <a href="blog-single.html"><img src="images/blog_sidebar_area_img_01.jpg" alt="images"></a>
                                <h4 class="date_position">25 JUNE 2017</h4>
                            </div>

                            <div class="blog_left_single_content para_default">
                                <h3><a href="blog-single.html">Make your productive teams</a></h3>
                                <p>Make your productive teams Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce pharetra ligula vitae mattis commodo. Phasellus consequat ipsum id mauris viverra, ac pulvinar dui fringilla. Ut suscipit ac turpis vitae accumsan. Fusce risus est, sagittis in lectus …</p>
                            </div>
                        </div><!-- blog_left_single_item -->

                        <div class="blog_left_single_item">
                            <div class="blog_pic image_fulwidth">
                                <a href="blog-single.html"><img src="images/blog_sidebar_area_img_02.jpg" alt="images"></a>
                                <h4 class="date_position">25 JUNE 2017</h4>
                            </div>

                            <div class="blog_left_single_content para_default">
                                <h3><a href="blog-single.html">Make your productive teams</a></h3>
                                <p>Make your productive teams Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce pharetra ligula vitae mattis commodo. Phasellus consequat ipsum id mauris viverra, ac pulvinar dui fringilla. Ut suscipit ac turpis vitae accumsan. Fusce risus est, sagittis in lectus …</p>
                            </div>
                        </div><!-- blog_left_single_item -->

                        <div class="blog_left_single_item">
                            <div class="blog_pic image_fulwidth">
                                <a href="blog-single.html"><img src="images/blog_sidebar_area_img_03.jpg" alt="images"></a>
                                <h4 class="date_position">25 JUNE 2017</h4>
                            </div>

                            <div class="blog_left_single_content para_default">
                                <h3><a href="blog-single.html">Make your productive teams</a></h3>
                                <p>Make your productive teams Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce pharetra ligula vitae mattis commodo. Phasellus consequat ipsum id mauris viverra, ac pulvinar dui fringilla. Ut suscipit ac turpis vitae accumsan. Fusce risus est, sagittis in lectus …</p>
                            </div>
                        </div><!-- blog_left_single_item -->

                        <div class="blog_left_single_item">
                            <div class="blog_pic image_fulwidth">
                                <a href="blog-single.html"><img src="images/blog_sidebar_area_img_04.jpg" alt="images"></a>
                                <h4 class="date_position">25 JUNE 2017</h4>
                            </div>

                            <div class="blog_left_single_content para_default">
                                <h3><a href="blog-single.html">Make your productive teams</a></h3>
                                <p>Make your productive teams Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce pharetra ligula vitae mattis commodo. Phasellus consequat ipsum id mauris viverra, ac pulvinar dui fringilla. Ut suscipit ac turpis vitae accumsan. Fusce risus est, sagittis in lectus …</p>
                            </div>
                        </div><!-- blog_left_single_item -->
                        
                        <div class="blog_pagination">
                            <nav>
                                <ul class="pagination pagination-lg">
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>

                                    <li class="page-item">
                                        <a class="page-link" href="#"><i class="flaticon-right-arrow"></i></a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div><!-- blog_left_side_area -->
					
                </div><!-- col-md-8 -->
				
				
                <div class="col-md-4">
                    <div class="blog_right_side_area">
					
                        <div class="blog_right_widget">
                            <div class="blog_widget">
                                <form action="#" method="post" class="blog_search">
                                    <input type="text" placeholder="Search...">
                                    <div class="blog_search_btn"> <input type="submit" value=""></div>
                                </form>
                            </div>
                        </div><!-- blog_right_widget  -->
						
                        
                        <div class="blog_right_widget">
                            <div class="blog_widget">
                                <h3 class="blog_widget_title">Categories</h3>
                                <ul>
                                    <li><a href="service-details-page-01.html">Business Modules</a></li>
                                    <li><a href="service-details-page-02.html">Development</a></li>
                                    <li><a href="service-details-page-03.html">Consultancy Service</a></li>
                                    <li><a href="service-details-page-04.html">Marketing Strategy</a></li>
                                    <li><a href="service-details-page-05.html">Finance Management</a></li>
                                    <li><a href="service-details-page-06.html">Audit & Assurance</a></li>
                                    <li><a href="service-details-page-07.html">Taxation</a></li>
                                </ul>
                            </div>
                        </div><!-- blog_right_widget  -->


                        <div class="blog_right_widget">
                            <div class="blog_widget">
                                <h3 class="blog_widget_title">Project</h3>
                                <div class="project_div clearfix">
                                    <figure class="image">
                                        <a href="images/blog_project_item_01.jpg" data-fancybox="gallery">
                                            <img src="images/blog_project_item_01.jpg" alt="images">
                                        </a>
                                    </figure>

                                    <figure class="image">
                                        <a href="images/blog_project_item_02.jpg" data-fancybox="gallery">
                                            <img src="images/blog_project_item_02.jpg" alt="images">
                                        </a>
                                    </figure>

                                    <figure class="image">
                                        <a href="images/blog_project_item_03.jpg" data-fancybox="gallery">
                                            <img src="images/blog_project_item_03.jpg" alt="images">
                                        </a>
                                    </figure>

                                    <figure class="image">
                                        <a href="images/blog_project_item_04.jpg" data-fancybox="gallery">
                                            <img src="images/blog_project_item_04.jpg" alt="images">
                                        </a>
                                    </figure>

                                    <figure class="image">
                                        <a href="images/blog_project_item_05.jpg" data-fancybox="gallery">
                                            <img src="images/blog_project_item_05.jpg" alt="images">
                                        </a>
                                    </figure>

                                    <figure class="image">
                                        <a href="images/blog_project_item_06.jpg" data-fancybox="gallery">
                                            <img src="images/blog_project_item_06.jpg" alt="images">
                                        </a>
                                    </figure>
                                </div>
                            </div>
                        </div><!-- blog_right_widget  -->

                        <div class="blog_right_widget">
                            <div class="blog_widget">
                                <h3 class="blog_widget_title">Archive</h3>
                                <form action="#" method="post">
                                    <div class="form-group">
                                        <select>
                                            <option value="Select Month">
                                                Select Month
                                            </option>
                                            <option value="saab">
                                                January 2017
                                            </option>
                                            <option value="mercedes">
                                                february 2017
                                            </option>
                                            <option value="audi">
                                                March 2017
                                            </option>
                                            <option value="audi">
                                                April 2017
                                            </option>
                                            <option value="audi">
                                                August 2017
                                            </option>
                                            <option value="audi">
                                                Dcember 2017
                                            </option>
                                        </select>
                                    </div>
                                </form>
                            </div>
                        </div><!-- blog_right_widget  -->
                    </div>
                </div><!-- col-md-4 -->
            </div><!-- row -->
        </div><!-- container -->
    </div><!-- blog_page_area -->

<?php get_footer(); ?>