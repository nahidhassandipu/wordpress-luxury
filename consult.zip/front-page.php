<?php
/**
 * Template Name : Consult Home
 * The front page template file
 *
 * If the user has selected a static page for their homepage, this is what will
 * appear.
 * Learn more: https://codex.wordpress.org/Template_Hierarchy
 * @since 1.0
 * @version 1.0
 */
?>



<?php get_header(); ?>
    
            
    <div id="home_default_rev_slider_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="focus-parallax" data-source="gallery" style="background-color:transparent;padding:0px;">
        <div id="home_default" class="rev_slider fullscreenbanner" style="display:none;">
            <ul>
                <li data-index="digital_slide_1" data-transition="crossfade" data-slotamount="default"  data-easein="default" data-easeout="default" data-masterspeed="500"  data-rotate="0"  data-saveperformance="off"  data-title="Focus">

                    <img src="<?php echo $redux_demo['slider_image_1_home']['url']; ?>" alt="images"  data-lazyload="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>

                    <div class="tp-caption tp-resizeme" 
                        id="slide-1-layer-1" 
                        data-x="['left','left','left','left']" data-hoffset="['0','50','50','50']" 
                        data-y="['center','center','center','center']" data-voffset="['-100','-80','-60','-50']" 
                        data-fontsize="['85','70','50','40']" 
                        data-lineheight="['85','70','50','50']" 
                        data-width="none" 
                        data-height="none" 
                        data-whitespace="nowrap" 
                        data-type="text" 
                        data-responsive_offset="on" 
                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","speed":2000,"to":"o:1;","delay":750,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]' 
                        data-textAlign="['left','left','left','left']" 
                        data-paddingtop="[0,0,0,0]" 
                        data-paddingright="[0,0,0,0]" 
                        data-paddingbottom="[0,0,0,0]" 
                        data-paddingleft="[0,0,0,0]" 
                        style="z-index: 6;font-size: 85px; white-space: nowrap;text-transform:left;color: #000;font-family: 'Montserrat', sans-serif;font-weight: 700;">
                        <?php echo $redux_demo['slider_image_1_text'] ?>
                    </div>

                     <div class="tp-caption rev-btn " 
                        id="slide-1-layer-5" 
                        data-x="['left','left','left','left']" data-hoffset="['0','50','50','50']" 
                        data-y="['center','center','center','center']" data-voffset="['110','90','70','60']"
                        data-fontsize="['18','15','14','13']" 
                        data-lineheight="['18','15','14','13']" 
                        data-width="none"
                        data-height="none"
                        data-whitespace="nowrap"
                        data-type="button" 
                        data-actions='[{"event":"click","action":"scrollbelow","offset":"px","delay":""}]'
                        data-responsive_offset="on" 
                        data-responsive="on"
                        data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"x:[-100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'  
                        data-textAlign="['left','left','left','left']" 
                        data-paddingtop="[14,13,12,12]" 
                        data-paddingright="[30,30,25,20]" 
                        data-paddingbottom="[14,12,13,12]" 
                        data-paddingleft="[30,30,25,20]" 
                        style="z-index: 8; white-space: nowrap; font-size: 18px; line-height: 15px; font-weight: 600; color: #fff;font-family: 'Montserrat', sans-serif;font-weight: 600;background-color:#008cb5;border-color:#008cb5;border-style:solid;border-width:1px;border-radius:30px 30px 30px 30px;letter-spacing:1px;">Read More 
                    </div>
                </li>

                <li data-index="digital_slide_2" data-transition="crossfade" data-slotamount="default"  data-easein="default" data-easeout="default" data-masterspeed="500"  data-rotate="0"  data-saveperformance="off"  data-title="Focus">

                    <img src="<?php echo $redux_demo['slider_image_2_home']['url']; ?>" alt="images"  data-lazyload="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>

                    <div class="tp-caption  tp-resizeme" 
                        id="slide-2-layer-1" 
                        data-x="['left','left','left','left']" data-hoffset="['0','50','50','50']" 
                        data-y="['center','center','center','center']" data-voffset="['-100','-80','-60','-50']" 
                        data-fontsize="['85','70','50','40']" 
                        data-lineheight="['85','70','50','50']" 
                        data-width="none" 
                        data-height="none" 
                        data-whitespace="nowrap" 
                        data-type="text" 
                        data-responsive_offset="on" 
                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","speed":2000,"to":"o:1;","delay":750,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]' 
                        data-textAlign="['left','left','left','left']" 
                        data-paddingtop="[0,0,0,0]" 
                        data-paddingright="[0,0,0,0]" 
                        data-paddingbottom="[0,0,0,0]" 
                        data-paddingleft="[0,0,0,0]" 
                        style="z-index: 6;font-size: 85px; white-space: nowrap;text-transform:left;color: #000;font-family: 'Montserrat', sans-serif;font-weight: 700;">
                        <?php echo $redux_demo['slider_image_2_text'] ?>
                    </div>
                    
                     <div class="tp-caption rev-btn " 
                        id="slide-2-layer-4" 
                        data-x="['left','left','left','left']" data-hoffset="['0','50','50','50']" 
                        data-y="['center','center','center','center']" data-voffset="['110','90','70','60']"
                        data-fontsize="['18','15','14','13']" 
                        data-lineheight="['18','15','14','13']" 
                        data-width="none"
                        data-height="none"
                        data-whitespace="nowrap"
                        data-type="button" 
                        data-actions='[{"event":"click","action":"scrollbelow","offset":"px","delay":""}]'
                        data-responsive_offset="on" 
                        data-responsive="on"
                        data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"x:[-100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'  
                        data-textAlign="['left','left','left','left']" 
                        data-paddingtop="[14,13,12,12]" 
                        data-paddingright="[30,30,25,20]" 
                        data-paddingbottom="[14,12,13,12]" 
                        data-paddingleft="[30,30,25,20]" 
                        style="z-index: 8; white-space: nowrap; font-size: 18px; line-height: 15px; font-weight: 600; color: #fff;font-family: 'Montserrat', sans-serif;font-weight: 600;background-color:#008cb5;border-color:#008cb5;border-style:solid;border-width:1px;border-radius:30px 30px 30px 30px;letter-spacing:1px;">Read More 
                    </div>
                </li> 
            </ul>
        </div>
    </div><!-- END REVOLUTION SLIDER -->
    
    <div class="looking_for_specific_area">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="looking_for_left para_default">
                        <h3><?php global $redux_demo; echo $redux_demo['Abouthomepage']; ?></h3>
                        <p><?php echo $redux_demo['Abouthomepage_description']; ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="looking_for_right image_fulwidth wow fadeInRight" data-wow-delay="300ms">
                        <img src="<?php echo $redux_demo['about-media-home']['url']; ?>" alt="images">
                    </div>
                </div>
            </div><!--row -->
        </div><!--container -->
        <div id="our_services_id"></div>
    </div><!--looking_for_specific_area -->
    
    
    <?php $our_services = new WP_Query(array(
        'post_type' => 'services_post',
        'posts_per_page'    =>  3,
    )); ?>
	
	<div class="why_choose_us_area">
        <div class="container">
            <div class="row">
				<div class="item single_blog_item_div para_default text-center">
					<h2><a>Our Services</a></h2>
				</div>
				
		<?php while($our_services->have_posts()): $our_services->the_post(); ?>
                <div class="col-md-4 col-sm-12">
                    <div class="choose_us_single para_default image_fulwidth text-center wow fadeInLeft" data-wow-delay="300ms">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail(); ?>
                        </a>
                        <h3><?php the_title(); ?></h3>
                        <p><?php read_more("22"); ?></p>
                    </div>
                </div><!--col-md-4 -->
        <?php endwhile; ?>
                
                
            </div><!--row -->
        </div><!--container-fluid -->
    </div><!--about_section_area -->
	
	
	<?php 
	$our_work = new WP_Query(array(
	    'post_type' => 'our_works',
	    'posts_per_page' => 3
	)); ?>
    <div class="about_section_area">
        <div class="container-fluid">
            <div class="row">
				<div class="item single_blog_item_div para_default text-center">
					<h2><a>Our Works</a></h2>
				</div>
                
            <?php while($our_work->have_posts()): $our_work->the_post(); ?>
                <div class="col-md-4 col-sm-12">
                    <div class="about_Single_item para_default text-center wow fadeInLeft our_work_block" data-wow-delay="300ms">
                        <?php the_post_thumbnail(); ?>
                        <h3><?php the_title(); ?></h3>
                        <p><?php read_more("12"); ?></p>
                    </div>
                </div><!--col-md-4 -->
            <?php endwhile; ?>    

            </div><!--row -->
        </div><!--container-fluid -->
    </div><!--about_section_area -->
	
    <div class="latest_blog_section_area removeBg_latest_blog">
        <div class="container">
            <div class="row">
				<div class="item single_blog_item_div para_default text-center">
					<h2><a>Latest News</a></h2>
				</div>
				
			<?php
    			$args = array( 'numberposts' => '3' );
    			$recent_posts = wp_get_recent_posts($args); 
			    
			    foreach( $recent_posts as $recent ){ ?>
                
                <div class="col-md-4 col-sm-12">
                    <div class="single_blog_h_active">
                        <div class="single_blog_item_area para_default image_fulwidth text-center">
                            <?php echo get_the_post_thumbnail( $recent["ID"] ); ?>
                            <h4>
                                <?php echo get_the_time( 'd-M-y', $recent["ID"] ); ?>
                            </h4>
                            <h3>
                                <a href="<?php echo get_permalink($recent["ID"]); ?> ">
                                    <?php echo $recent["post_title"] ?>
                                </a>
                            </h3>
                            <p>
                                <?php echo $recent["post_content"] ?>
                            </p>
                        </div>
					</div>
				</div>
				
            <?php } ?>  
            
            </div>
        </div><!-- container-->
    </div><!-- latest_blog_section_area-->

<?php get_footer(); ?>
