<style>
    input.search-submit {
        background-image: url(<?php echo get_template_directory_uri().'/images/find.png' ?>);
        background-repeat: no-repeat;
        background-position: center center;
        background-size: cover;
        border-radius: 50%;
    }
    input.search-submit:hover, input.search-submit:focus {
        opacity: 0.7;
    }

</style>

<?php if ( is_active_sidebar( 'sidebar-1' )  ) : ?>
	    <div class="blog_right_side_area">
            <div class="blog_right_widget">
                <div class="blog_widget">
                    <?php dynamic_sidebar( 'sidebar-1' ); ?>
                </div>
            </div><!-- blog_right_widget  -->

            <div class="blog_right_widget">
                <div class="blog_widget">
                    <h3 class="blog_widget_title">Project</h3>
                    <div class="project_div clearfix">
                        <?php global $redux_demo;
			for ($i=0; $i < count($redux_demo['Project_imgas_for_sidebar']); $i++) { ?>
                        <figure class="image">
                            <a href="<?php echo $redux_demo['Project_imgas_for_sidebar'][$i]['image']; ?>" data-fancybox="gallery">
                                
                                <img src="<?php echo $redux_demo['Project_imgas_for_sidebar'][$i]['image']; ?>" alt="images">
                            </a>
                        </figure>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    
<?php endif; ?>




