<style>
    .faqs_title_bg {
        background: url('<?php echo to_get_featured_image();?>') no-repeat scroll center center;
    }
</style>
<?php
/*

Template Name: About Page

*/
?>
<?php get_header(); ?>

    
    <div class="page_title_banner faqs_title_bg">
        <div class="page_title_banner_overlay"></div>
        <div class="container">
            <div class="page_title_banner_text text-center">
                <?php the_title( '<h2 class="entry-title banner_effect">', '</h2>' ); ?>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Pages</a></li>
                    <li class="active"><?php the_title(); ?></li>
                </ul>
            </div>
        </div><!--container-->
    </div><!--page_title_banner-->

<?php global $redux_demo;  ?>

    <div class="about_page_tab_section_area">
        <div class="container">
            <div class="row">
                <div class="about_us_tab_area">
                    <div class="tab_menu_s_p_two">
                        <div class="col-md-12">
                            <ul class="tab_button_service">
                                
                      <?php for($i = 0; $i < count($redux_demo['about_us_page_section']); $i++) { ?>
                      <?php $title_id = $redux_demo['about_us_page_section'][$i]['title']; ?>
                                <li role="presentation" class="ta_button_Bg2">
                                    <a href="#<?php echo preg_replace('/\s+/', '', $title_id) ?>" aria-controls="Freelancer" role="tab" data-toggle="tab">
                                     <?php echo $redux_demo['about_us_page_section'][$i]['title']; ?></a>
                                </li>
                      <?php } ?>
                      
                            </ul>
                        </div>

                        <div class="tab-content">
                            
                  <?php for($i = 0; $i < count($redux_demo['about_us_page_section']); $i++) { ?>
                  <?php $title_id = $redux_demo['about_us_page_section'][$i]['title']; ?>
                            
                            <div role="tabpanel" class="tab-pane fade in" id="<?php echo preg_replace('/\s+/', '', $title_id) ?>">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="image_fulwidth wow fadeInLeft" data-wow-delay="300ms">
                                            <img src="<?php echo $redux_demo['about_us_page_section'][$i]['image']; ?>" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="tab_text_ser para_default">
                                                <h3><?php echo $redux_demo['about_us_page_section'][$i]['title']; ?></h3>
                                                <p><?php echo $redux_demo['about_us_page_section'][$i]['description']; ?></p>
                                                <ul class="list_for_type_of_visition">
                                                    
                                    <?php if($redux_demo['about_us_page_section'][$i]['list_1'] != "") { ?>
                                                    <li><i class="fa fa-dot-circle-o"></i> <?php echo $redux_demo['about_us_page_section'][$i]['list_1']; ?></li>
                                    <?php } ?>
                                    <?php if($redux_demo['about_us_page_section'][$i]['list_2'] != "") { ?>
                                                    <li><i class="fa fa-dot-circle-o"></i> <?php echo $redux_demo['about_us_page_section'][$i]['list_2']; ?></li>
                                    <?php } ?>                              
                                    <?php if($redux_demo['about_us_page_section'][$i]['list_3'] != "" ) { ?>
                                                    <li><i class="fa fa-dot-circle-o"></i> <?php echo $redux_demo['about_us_page_section'][$i]['list_3']; ?></li>
                                    <?php } ?>
                                    <?php if($redux_demo['about_us_page_section'][$i]['list_4'] != "") { ?>
                                                    <li><i class="fa fa-dot-circle-o"></i> <?php echo $redux_demo['about_us_page_section'][$i]['list_4']; ?></li>
                                    <?php } ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                  <?php } ?>
                            
                        </div>
                    </div>
                </div><!--about_us_tab_area-->
            </div><!-- row -->
        </div><!-- container -->
    </div><!-- about_page_tab_section_area -->
    
    <script>
        jQuery(document).ready(function($){
            $('ul.tab_button_service > li:first-child').addClass('active');
            $('.tab-pane:first-child').addClass('active');
        });
    </script>

<?php get_footer(); ?>