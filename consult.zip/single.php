<?php get_header(); ?>
    
    <div class="page_title_banner banner_blog_single_title_bg">
        <div class="page_title_banner_overlay"></div>
        <div class="container">
            <div class="page_title_banner_text text-center">
                <h2 class="banner_effect">Blog</h2>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Pages</a></li>
                    <li class="active">blog</li>
                </ul>
            </div>
        </div><!--container-->
    </div><!-- page_title_banner -->
    
    <div class="blog_page_area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="blog_left_side_area">
                    <?php while ( have_posts() ) : the_post();?>
                        <div class="blog_pic image_fulwidth">
                            <?php the_post_thumbnail(); ?>
                            <h4 class="date_position">
                                <?php the_date('d') ?> <?php the_time('M-y'); ?>
                            </h4>
                        </div>

                        <div class="blog_left_single_content blog_single_content para_default">
                            <h3><?php the_title(); ?></h3>
                            <p><?php the_content();?></p>
                        </div>

                        <div class="blog_tag">
                            <?php the_tags(); ?>
                        </div>
                        <hr>

                        <div class="share_blog_single_in_social">
                            <h4>
                                <span>Share</span> 
                                <a href="https://www.facebook.com">
									<i class="fa fa-facebook"></i></a>
                                <a href="https://www.twitter.com">
									<i class="fa fa-twitter"></i></a>
                                <a href="https://plus.google.com/discover">
									<i class="fa fa-google-plus"></i></a>
                                <a href="https://linkedin.com"><i class="fa fa-linkedin"></i></a>
                            </h4>
                        </div>
                    <?php endwhile; ?>
                    
                    <?php if ( comments_open() || get_comments_number() ) :
								comments_template();
						endif; ?>
					</div><!-- blog_left_side_area -->
                </div><!-- col-md-8 -->

                <div class="col-md-4">
                    <?php get_sidebar(); ?>
                </div><!-- col-md-4 -->
            </div><!-- row -->  
        </div><!-- container -->
    </div><!-- blog_page_area -->
    <script>
        jQuery(document).ready(function($) {
            $(".comment-form-author #author").attr("placeholder", "Name");  
            $(".comment-form-email #email").attr("placeholder", "Email");  
            $(".comment-form-url #url").attr("placeholder", "Website");  
            $(".consultency_comments_form textarea.form-control, textarea#comment").attr("placeholder", "Message");  
        });
    </script>
    
<?php get_footer(); ?>