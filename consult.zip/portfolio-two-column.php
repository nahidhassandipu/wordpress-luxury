<style>
    .faqs_title_bg {
        background: url('<?php echo to_get_featured_image();?>') no-repeat scroll center center;
    }
</style>
<?php
/*

Template Name: Portfolio

*/
?>
<?php get_header(); ?>

    
    <div class="page_title_banner faqs_title_bg">
        <div class="page_title_banner_overlay"></div>
        <div class="container">
            <div class="page_title_banner_text text-center">
                <?php the_title( '<h2 class="entry-title banner_effect">', '</h2>' ); ?>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Pages</a></li>
                    <li class="active"><?php the_title(); ?></li>
                </ul>
            </div>
        </div><!--container-->
    </div><!--page_title_banner-->

<?php global $redux_demo;  ?>

    <div class="portfolio_section_area">
        <div class="container">
            <div style="padding: 0 20px" class="row">
                
                <ul class="portfolio_nav_menu">
                    <li class="active"><a data-toggle="tab" href="#all"> All </a></li>
                    <li>
                        <a data-toggle="tab" href="#consulting">
                            <?php echo $redux_demo['consulting_portfolio_title']; ?>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#business">
                            <?php echo $redux_demo['business_portfolio_title']; ?>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#finance">
                            <?php echo $redux_demo['finance_portfolio_title']; ?>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#marketing">
                            <?php echo $redux_demo['marketing_portfolio_title']; ?>
                        </a>
                    </li>
                </ul>

                <div class="tab-content">
                    
                    <div role="tabpanel" class="tab-pane fade in active" id="all">
                        <div class="row">
                            
                            <?php for($i = 0; $i < count($redux_demo['consulting_portfolio_gallery']); $i++) { ?>
                                    <figure class="image">
                                        <a href="<?php echo $redux_demo['consulting_portfolio_gallery'][$i]['image']; ?>" data-fancybox="gallery">
                                            <div class="col-md-6">
                                                <div class="image_fulwidth wow fadeInLeft portfolio_image" data-wow-delay="300ms">
                                                    <img class="thumbnail" src="<?php echo $redux_demo['consulting_portfolio_gallery'][$i]['image']; ?>" alt="">
                                                </div>
                                            </div>
                                        </a>
                                    </figure>    
                            <?php } ?>
                           
                            <?php for($i = 0; $i < count($redux_demo['marketing_portfolio_gallery']); $i++) { ?>
                                    <figure class="image">
                                        <a href="<?php echo $redux_demo['marketing_portfolio_gallery'][$i]['image']; ?>" data-fancybox="gallery">
                                            <div class="col-md-6">
                                                <div class="image_fulwidth wow fadeInLeft portfolio_image" data-wow-delay="300ms">
                                                    <img class="thumbnail" src="<?php echo $redux_demo['marketing_portfolio_gallery'][$i]['image']; ?>" alt="">
                                                </div>
                                            </div>
                                        </a>
                                    </figure>
                            <?php } ?>
                           
                            <?php for($i = 0; $i < count($redux_demo['finance_portfolio_gallery']); $i++) { ?>
                                    <figure class="image">
                                        <a href="<?php echo $redux_demo['finance_portfolio_gallery'][$i]['image']; ?>" data-fancybox="gallery">
                                            <div class="col-md-6">
                                                <div class="image_fulwidth wow fadeInLeft portfolio_image" data-wow-delay="300ms">
                                                    <img class="thumbnail" src="<?php echo $redux_demo['finance_portfolio_gallery'][$i]['image']; ?>" alt="">
                                                </div>
                                            </div>
                                        </a>
                                    </figure>
                            <?php } ?>
                            
                            <?php for($i = 0; $i < count($redux_demo['business_portfolio_gallery']); $i++) { ?>
                                    <figure class="image">
                                        <a href="<?php echo $redux_demo['business_portfolio_gallery'][$i]['image']; ?>" data-fancybox="gallery">
                                            <div class="col-md-6">
                                                <div class="image_fulwidth wow fadeInLeft portfolio_image" data-wow-delay="300ms">
                                                    <img class="thumbnail" src="<?php echo $redux_demo['business_portfolio_gallery'][$i]['image']; ?>" alt="">
                                                </div>
                                            </div>
                                        </a>
                                    </figure>
                            <?php } ?>
                            
                        </div>
                    </div>
                    
                    
                    
                    <div role="tabpanel" class="tab-pane fade in" id="consulting">
                        <div class="row">
                            
                    <?php for($i = 0; $i < count($redux_demo['consulting_portfolio_gallery']); $i++) { ?>
                            <figure class="image">
                                <a href="<?php echo $redux_demo['consulting_portfolio_gallery'][$i]['image']; ?>" data-fancybox="gallery">
                                    <div class="col-md-6">
                                        <div class="image_fulwidth wow fadeInLeft portfolio_image" data-wow-delay="300ms">
                                            <img class="thumbnail" src="<?php echo $redux_demo['consulting_portfolio_gallery'][$i]['image']; ?>" alt="">
                                        </div>
                                    </div>
                                </a>
                            </figure>    
                    <?php } ?>
                    
                        </div>
                    </div>
                
                    <div role="tabpanel" class="tab-pane fade in" id="business">
                        <div class="row">
                    <?php for($i = 0; $i < count($redux_demo['business_portfolio_gallery']); $i++) { ?>
                            <figure class="image">
                                <a href="<?php echo $redux_demo['business_portfolio_gallery'][$i]['image']; ?>" data-fancybox="gallery">
                                    <div class="col-md-6">
                                        <div class="image_fulwidth wow fadeInLeft portfolio_image" data-wow-delay="300ms">
                                            <img class="thumbnail" src="<?php echo $redux_demo['business_portfolio_gallery'][$i]['image']; ?>" alt="">
                                        </div>
                                    </div>
                                </a>
                            </figure>
                    <?php } ?>
                        </div>
                    </div>
                
                    <div role="tabpanel" class="tab-pane fade in" id="finance">
                        <div class="row">
                    <?php for($i = 0; $i < count($redux_demo['finance_portfolio_gallery']); $i++) { ?>
                            <figure class="image">
                                <a href="<?php echo $redux_demo['finance_portfolio_gallery'][$i]['image']; ?>" data-fancybox="gallery">
                                    <div class="col-md-6">
                                        <div class="image_fulwidth wow fadeInLeft portfolio_image" data-wow-delay="300ms">
                                            <img class="thumbnail" src="<?php echo $redux_demo['finance_portfolio_gallery'][$i]['image']; ?>" alt="">
                                        </div>
                                    </div>
                                </a>
                            </figure>
                    <?php } ?>
                        </div>
                    </div>
                
                    <div role="tabpanel" class="tab-pane fade in" id="marketing">
                        <div class="row">
                    <?php for($i = 0; $i < count($redux_demo['marketing_portfolio_gallery']); $i++) { ?>
                            <figure class="image">
                                <a href="<?php echo $redux_demo['marketing_portfolio_gallery'][$i]['image']; ?>" data-fancybox="gallery">
                                    <div class="col-md-6">
                                        <div class="image_fulwidth wow fadeInLeft portfolio_image" data-wow-delay="300ms">
                                            <img class="thumbnail" src="<?php echo $redux_demo['marketing_portfolio_gallery'][$i]['image']; ?>" alt="">
                                        </div>
                                    </div>
                                </a>
                            </figure>
                    <?php } ?>
                        </div>
                    </div>
                </div>
                    
            </div><!-- row -->
        </div><!-- container -->
    </div><!-- portfolio_section_area -->

<?php get_footer(); ?>